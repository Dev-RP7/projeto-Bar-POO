// Produção. Troque pela URL da API publicada (ex.: Render).
export const environment = {
  apiUrl: 'https://nos-dois-api.onrender.com',
};
