// Desenvolvimento (ng serve): API rodando na sua máquina.
export const environment = {
  apiUrl: 'http://localhost:8080',
};
