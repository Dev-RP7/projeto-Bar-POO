import { Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Avisos } from './core/avisos';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  template: `
    <router-outlet />
    @if (avisos.atual(); as aviso) {
      <div class="toast" [class.erro]="aviso.erro" role="status">{{ aviso.texto }}</div>
    }
  `,
})
export class App {
  protected readonly avisos = inject(Avisos);
}
