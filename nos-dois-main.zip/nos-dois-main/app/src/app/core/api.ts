import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import {
  ConvitePublico, Gasto, GastoRequest, GastosMes, Historico, Juntos, Mensagem, Meta,
  Perfil, RegraDivisao, ResumoMes, Sessao,
} from './modelos';
import { SessaoService } from './sessao';

/** Todas as chamadas à API do Nós Dois. */
@Injectable({ providedIn: 'root' })
export class Api {
  private readonly http = inject(HttpClient);
  private readonly sessao = inject(SessaoService);
  private readonly url = environment.apiUrl;

  // ---------- Conta ----------
  cadastrar(nome: string, email: string, senha: string): Observable<Mensagem> {
    return this.http.post<Mensagem>(`${this.url}/auth/cadastro`, { nome, email, senha });
  }
  verificar(email: string, codigo: string): Observable<Sessao> {
    return this.http.post<Sessao>(`${this.url}/auth/verificar`, { email, codigo }).pipe(tap((s) => this.sessao.iniciar(s)));
  }
  reenviarCodigo(email: string): Observable<Mensagem> {
    return this.http.post<Mensagem>(`${this.url}/auth/reenviar-codigo`, { email });
  }
  entrar(email: string, senha: string): Observable<Sessao> {
    return this.http.post<Sessao>(`${this.url}/auth/login`, { email, senha }).pipe(tap((s) => this.sessao.iniciar(s)));
  }
  esqueciSenha(email: string): Observable<Mensagem> {
    return this.http.post<Mensagem>(`${this.url}/auth/esqueci-senha`, { email });
  }
  redefinirSenha(email: string, codigo: string, novaSenha: string): Observable<Sessao> {
    return this.http
      .post<Sessao>(`${this.url}/auth/redefinir-senha`, { email, codigo, novaSenha })
      .pipe(tap((s) => this.sessao.iniciar(s)));
  }

  // ---------- Perfil e convite ----------
  perfil(): Observable<Perfil> {
    return this.http.get<Perfil>(`${this.url}/perfil`).pipe(tap((p) => this.sessao.atualizarPerfil(p)));
  }
  alterarNome(nome: string): Observable<Perfil> {
    return this.http.patch<Perfil>(`${this.url}/perfil/nome`, { nome }).pipe(tap((p) => this.sessao.atualizarPerfil(p)));
  }
  trocarSenha(senhaAtual: string, novaSenha: string): Observable<void> {
    return this.http.patch<void>(`${this.url}/perfil/senha`, { senhaAtual, novaSenha });
  }
  alterarRegra(regra: RegraDivisao): Observable<Perfil> {
    return this.http.put<Perfil>(`${this.url}/perfil/regra-divisao`, { regra }).pipe(tap((p) => this.sessao.atualizarPerfil(p)));
  }
  convite(codigo: string): Observable<ConvitePublico> {
    return this.http.get<ConvitePublico>(`${this.url}/convites/${encodeURIComponent(codigo)}`);
  }
  aceitarConvite(codigo: string): Observable<Perfil> {
    return this.http.post<Perfil>(`${this.url}/perfil/convite/aceitar`, { codigo }).pipe(tap((p) => this.sessao.atualizarPerfil(p)));
  }
  sairDoCasal(): Observable<Perfil> {
    return this.http.post<Perfil>(`${this.url}/perfil/sair-do-casal`, {}).pipe(tap((p) => this.sessao.atualizarPerfil(p)));
  }
  backup(): Observable<unknown> {
    return this.http.get(`${this.url}/backup`);
  }

  // ---------- Mês e rendas ----------
  mes(mes: string): Observable<ResumoMes> {
    return this.http.get<ResumoMes>(`${this.url}/meses`, { params: { mes } });
  }
  definirRenda(mes: string, valor: number): Observable<ResumoMes> {
    return this.http.put<ResumoMes>(`${this.url}/rendas/${mes}`, { valor });
  }

  // ---------- Gastos ----------
  gastos(mes: string): Observable<GastosMes> {
    return this.http.get<GastosMes>(`${this.url}/gastos`, { params: { mes } });
  }
  criarGasto(g: GastoRequest): Observable<Gasto> {
    return this.http.post<Gasto>(`${this.url}/gastos`, g);
  }
  atualizarGasto(id: number, g: GastoRequest): Observable<Gasto> {
    return this.http.put<Gasto>(`${this.url}/gastos/${id}`, g);
  }
  excluirGasto(id: number): Observable<void> {
    return this.http.delete<void>(`${this.url}/gastos/${id}`);
  }

  // ---------- Histórico ----------
  historicoDias(mes: string): Observable<Historico> {
    return this.http.get<Historico>(`${this.url}/historico/dias`, { params: { mes } });
  }
  historicoMeses(ano: number): Observable<Historico> {
    return this.http.get<Historico>(`${this.url}/historico/meses`, { params: { ano } });
  }
  historicoAnos(): Observable<Historico> {
    return this.http.get<Historico>(`${this.url}/historico/anos`);
  }

  // ---------- Juntos ----------
  juntos(): Observable<Juntos> {
    return this.http.get<Juntos>(`${this.url}/juntos`);
  }
  criarMeta(nome: string, valorAlvo: number | null, prazo: string | null): Observable<Meta> {
    return this.http.post<Meta>(`${this.url}/metas`, { nome, valorAlvo, prazo });
  }
  atualizarMeta(id: number, nome: string, valorAlvo: number | null, prazo: string | null): Observable<Meta> {
    return this.http.put<Meta>(`${this.url}/metas/${id}`, { nome, valorAlvo, prazo });
  }
  excluirMeta(id: number): Observable<void> {
    return this.http.delete<void>(`${this.url}/metas/${id}`);
  }
  depositar(metaId: number, valor: number, data: string | null): Observable<Meta> {
    return this.http.post<Meta>(`${this.url}/metas/${metaId}/depositos`, { valor, data });
  }
  excluirDeposito(metaId: number, depositoId: number): Observable<Meta> {
    return this.http.delete<Meta>(`${this.url}/metas/${metaId}/depositos/${depositoId}`);
  }
}
