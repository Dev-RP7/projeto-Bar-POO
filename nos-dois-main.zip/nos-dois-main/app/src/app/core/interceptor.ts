import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, from, switchMap, throwError } from 'rxjs';
import { environment } from '../../environments/environment';
import { SessaoService } from './sessao';

/**
 * Coloca o token nas chamadas à API. Se a API responder 401 (token expirado),
 * renova uma vez e repete a chamada.
 */
export const autenticacaoInterceptor: HttpInterceptorFn = (req, next) => {
  const sessao = inject(SessaoService);
  if (!req.url.startsWith(environment.apiUrl) || req.url.includes('/auth/')) {
    return next(req);
  }

  const comToken = (token: string | null) =>
    token ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : req;

  return next(comToken(sessao.accessToken)).pipe(
    catchError((erro: unknown) => {
      if (!(erro instanceof HttpErrorResponse) || erro.status !== 401 || !sessao.logado()) {
        return throwError(() => erro);
      }
      return from(sessao.renovar()).pipe(
        switchMap((novo) => (novo ? next(comToken(novo)) : throwError(() => erro))),
      );
    }),
  );
};
