import { computed, inject, Injectable, signal } from '@angular/core';
import { HttpBackend, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../environments/environment';
import { Perfil, Sessao } from './modelos';

const CHAVE = 'nos-dois.sessao';

/**
 * Guarda a sessão (token de acesso, token de renovação e perfil) no aparelho
 * e renova o token de acesso quando ele expira.
 */
@Injectable({ providedIn: 'root' })
export class SessaoService {
  private readonly router = inject(Router);
  // HttpClient "cru", sem o interceptor, para a renovação não entrar em loop.
  private readonly http = new HttpClient(inject(HttpBackend));

  private readonly sessao = signal<Sessao | null>(ler());
  private renovando: Promise<string | null> | null = null;

  readonly logado = computed(() => this.sessao() !== null);
  readonly perfil = computed(() => this.sessao()?.perfil ?? null);
  readonly euId = computed(() => this.sessao()?.perfil.id ?? 0);
  /** A outra pessoa do casal, se já estiver conectada. */
  readonly parceiro = computed(() => this.perfil()?.pessoas.find((p) => !p.eu) ?? null);

  get accessToken(): string | null {
    return this.sessao()?.accessToken ?? null;
  }

  iniciar(sessao: Sessao): void {
    this.sessao.set(sessao);
    gravar(sessao);
  }

  atualizarPerfil(perfil: Perfil): void {
    const atual = this.sessao();
    if (!atual) return;
    const nova = { ...atual, perfil };
    this.sessao.set(nova);
    gravar(nova);
  }

  /** Troca o token de renovação por um par novo. Várias chamadas simultâneas compartilham a mesma renovação. */
  renovar(): Promise<string | null> {
    const atual = this.sessao();
    if (!atual) return Promise.resolve(null);
    this.renovando ??= firstValueFrom(
      this.http.post<Sessao>(`${environment.apiUrl}/auth/renovar`, { refreshToken: atual.refreshToken }),
    )
      .then((nova) => {
        this.iniciar(nova);
        return nova.accessToken;
      })
      .catch(() => {
        this.encerrarLocal();
        return null;
      })
      .finally(() => (this.renovando = null));
    return this.renovando;
  }

  async sair(): Promise<void> {
    const atual = this.sessao();
    if (atual) {
      try {
        await firstValueFrom(this.http.post(`${environment.apiUrl}/auth/sair`, { refreshToken: atual.refreshToken }));
      } catch {
        // Mesmo sem internet, a sessão local é apagada.
      }
    }
    this.encerrarLocal();
  }

  encerrarLocal(): void {
    this.sessao.set(null);
    try {
      localStorage.removeItem(CHAVE);
    } catch {}
    this.router.navigateByUrl('/entrar');
  }
}

function ler(): Sessao | null {
  try {
    const texto = localStorage.getItem(CHAVE);
    return texto ? (JSON.parse(texto) as Sessao) : null;
  } catch {
    return null;
  }
}

function gravar(sessao: Sessao): void {
  try {
    localStorage.setItem(CHAVE, JSON.stringify(sessao));
  } catch {}
}
