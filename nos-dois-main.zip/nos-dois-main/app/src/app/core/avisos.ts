import { Injectable, signal } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ErroApi } from './modelos';

/** Mensagens curtas que aparecem por cima da tela ("toast"). */
@Injectable({ providedIn: 'root' })
export class Avisos {
  readonly atual = signal<{ texto: string; erro: boolean } | null>(null);
  private timer?: ReturnType<typeof setTimeout>;

  mostrar(texto: string, erro = false): void {
    this.atual.set({ texto, erro });
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.atual.set(null), 3500);
  }

  erro(e: unknown): void {
    this.mostrar(mensagemDeErro(e), true);
  }
}

/** Extrai a mensagem amigável de um erro da API. */
export function mensagemDeErro(e: unknown): string {
  if (e instanceof HttpErrorResponse) {
    if (e.status === 0) return 'Sem conexão com o servidor. Tente de novo.';
    const corpo = e.error as Partial<ErroApi> | null;
    if (corpo?.campos?.length) return corpo.campos[0].mensagem;
    if (corpo?.mensagem) return corpo.mensagem;
  }
  return 'Algo deu errado. Tente de novo.';
}

export function codigoDeErro(e: unknown): string | undefined {
  return e instanceof HttpErrorResponse ? (e.error as Partial<ErroApi> | null)?.codigo : undefined;
}
