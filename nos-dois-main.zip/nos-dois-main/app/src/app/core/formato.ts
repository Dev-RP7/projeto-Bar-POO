// Formatação em português do Brasil e utilidades de datas.

const real = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

export function moeda(valor: number | null | undefined): string {
  return real.format(valor ?? 0);
}

/** Aceita "1600", "1.600,50", "1600.5" ou "R$ 1.600,50". Devolve null se não for um número válido. */
export function lerValor(texto: string | number | null | undefined): number | null {
  if (texto === null || texto === undefined) return null;
  if (typeof texto === 'number') return isFinite(texto) ? Math.round(texto * 100) / 100 : null;
  let t = texto.replace(/[^\d.,-]/g, '').trim();
  if (!t) return null;
  if (t.includes(',')) t = t.replace(/\./g, '').replace(',', '.');
  else if ((t.match(/\./g) ?? []).length > 1) t = t.replace(/\./g, '');
  const n = Number(t);
  return isFinite(n) ? Math.round(n * 100) / 100 : null;
}

/** Valor para preencher um campo de texto: 1600.5 -> "1600,50". */
export function valorParaCampo(valor: number | null | undefined): string {
  return valor === null || valor === undefined ? '' : valor.toFixed(2).replace('.', ',');
}

const NOMES_MES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho',
  'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

/** Mês atual no formato "AAAA-MM", pela data do aparelho. */
export function mesAtual(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export function somarMeses(mes: string, delta: number): string {
  const [a, m] = mes.split('-').map(Number);
  const d = new Date(a, m - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

/** "2026-10" -> "Outubro de 2026". */
export function nomeMes(mes: string): string {
  const [a, m] = mes.split('-').map(Number);
  const nome = NOMES_MES[m - 1];
  return `${nome[0].toUpperCase()}${nome.slice(1)} de ${a}`;
}

/** Data de hoje no formato "AAAA-MM-DD", pelo fuso do aparelho. */
export function hoje(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/** "2026-10-07" -> "terça, 7 de outubro" (ou "Hoje" / "Ontem"). */
export function nomeDia(data: string): string {
  if (data === hoje()) return 'Hoje';
  const [a, m, d] = data.split('-').map(Number);
  const dt = new Date(a, m - 1, d);
  const ontem = new Date();
  ontem.setDate(ontem.getDate() - 1);
  if (dt.toDateString() === ontem.toDateString()) return 'Ontem';
  const semana = dt.toLocaleDateString('pt-BR', { weekday: 'long' }).replace('-feira', '');
  return `${semana[0].toUpperCase()}${semana.slice(1)}, ${d} de ${NOMES_MES[m - 1]}`;
}

/** "2027-06" -> "jun/2027". */
export function mesCurto(mes: string | null): string {
  if (!mes) return '';
  const [a, m] = mes.split('-').map(Number);
  return `${NOMES_MES[m - 1].slice(0, 3)}/${a}`;
}

export function iniciais(nome: string): string {
  const partes = nome.trim().split(/\s+/).filter(Boolean);
  if (!partes.length) return '?';
  return (partes[0][0] + (partes.length > 1 ? partes[partes.length - 1][0] : '')).toUpperCase();
}
