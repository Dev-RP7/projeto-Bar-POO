import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { SessaoService } from './sessao';

/** Páginas do app: exigem login. Guarda o destino para voltar depois de entrar. */
export const precisaLogin: CanActivateFn = (_route, state) => {
  const sessao = inject(SessaoService);
  return sessao.logado() ? true : inject(Router).createUrlTree(['/entrar'], { queryParams: { voltar: state.url } });
};

/** Telas de entrada: quem já está logado vai direto para o mês. */
export const soVisitante: CanActivateFn = () => {
  const sessao = inject(SessaoService);
  return sessao.logado() ? inject(Router).createUrlTree(['/mes']) : true;
};
