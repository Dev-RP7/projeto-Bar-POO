// Formatos devolvidos pela API (espelham os DTOs do Spring Boot).

export type RegraDivisao = 'PROPORCIONAL' | 'IGUAL';
export type Categoria =
  | 'MORADIA' | 'MERCADO' | 'CONTAS_DA_CASA' | 'TRANSPORTE'
  | 'SAUDE' | 'LAZER' | 'EDUCACAO' | 'OUTROS';

export interface Pessoa { id: number; nome: string; eu: boolean; }
export interface Convite { codigo: string; link: string; }

export interface Perfil {
  id: number;
  nome: string;
  email: string;
  casalId: number;
  regraDivisao: RegraDivisao;
  pessoas: Pessoa[];
  convite: Convite | null;
}

export interface Sessao {
  accessToken: string;
  refreshToken: string;
  expiraEmSegundos: number;
  perfil: Perfil;
}

export interface Mensagem { mensagem: string; }

export interface ConvitePublico { codigo: string; nomeDeQuemConvidou: string | null; disponivel: boolean; }

export interface PessoaMes {
  id: number; nome: string; eu: boolean;
  renda: number; rendaRepetida: boolean;
  parteContasCasal: number; contasIndividuais: number;
  totalPaga: number; sobra: number;
}

export interface ResumoMes {
  mes: string;
  regraDivisao: RegraDivisao;
  pessoas: PessoaMes[];
  totalRendas: number;
  contasCasal: number;
  totalGastos: number;
  sobraCasal: number;
  depositosNoMes: number;
  disponivelParaGuardar: number;
  porCategoria: { categoria: Categoria; rotulo: string; total: number }[];
  reserva: { mediaMensalGastos: number; minimo: number; maximo: number };
}

export interface Gasto {
  id: number; data: string; descricao: string; valor: number;
  categoria: Categoria; categoriaRotulo: string;
  donoId: number | null; donoNome: string | null;
  criadoPorId: number; criadoPorNome: string;
}

export interface GastoRequest {
  data: string; descricao: string; valor: number; categoria: Categoria; donoId: number | null;
}

export interface GastosMes {
  mes: string; total: number;
  dias: { data: string; total: number; gastos: Gasto[] }[];
}

export interface LinhaHistorico {
  periodo: string; rotulo: string;
  entrou: number; saiu: number; sobrou: number; guardado: number;
  futuro: boolean;
}

export interface Historico { tipo: string; periodo: string; linhas: LinhaHistorico[]; total: LinhaHistorico; }

export interface Deposito { id: number; data: string; valor: number; criadoPorNome: string; }

export interface Meta {
  id: number; nome: string; valorAlvo: number | null; prazo: string | null;
  guardado: number; progresso: number; alcancada: boolean; prazoVencido: boolean;
  parcelaMensal: number | null;
  partesDaParcela: { id: number; nome: string; valor: number }[];
  depositos: Deposito[];
}

export interface Juntos {
  totalGuardado: number;
  disponivelParaGuardar: number;
  metas: Meta[];
  ideias: string[];
}

export interface ErroApi {
  status: number;
  codigo: string;
  mensagem: string;
  campos?: { campo: string; mensagem: string }[];
}

export const CATEGORIAS: { valor: Categoria; rotulo: string; icone: string }[] = [
  { valor: 'MORADIA', rotulo: 'Moradia', icone: '🏠' },
  { valor: 'MERCADO', rotulo: 'Mercado', icone: '🛒' },
  { valor: 'CONTAS_DA_CASA', rotulo: 'Contas da casa', icone: '💡' },
  { valor: 'TRANSPORTE', rotulo: 'Transporte', icone: '🚗' },
  { valor: 'SAUDE', rotulo: 'Saúde', icone: '🩺' },
  { valor: 'LAZER', rotulo: 'Lazer', icone: '🎉' },
  { valor: 'EDUCACAO', rotulo: 'Educação', icone: '📚' },
  { valor: 'OUTROS', rotulo: 'Outros', icone: '📦' },
];

export function iconeCategoria(c: Categoria): string {
  return CATEGORIAS.find((x) => x.valor === c)?.icone ?? '📦';
}
