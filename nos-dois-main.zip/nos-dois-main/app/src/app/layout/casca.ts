import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

/** Casca do app logado: conteúdo + barra de navegação inferior. */
@Component({
  selector: 'app-casca',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <router-outlet />
    <nav class="nav" aria-label="Navegação principal">
      @for (aba of abas; track aba.rota) {
        <a [routerLink]="aba.rota" routerLinkActive="ativo" [attr.aria-label]="aba.nome">
          <span class="ico" aria-hidden="true">{{ aba.icone }}</span>
          <span>{{ aba.nome }}</span>
        </a>
      }
    </nav>
  `,
  styles: `
    .nav {
      position: fixed;
      left: 0; right: 0; bottom: 0;
      z-index: 30;
      height: calc(var(--nav-h) + env(safe-area-inset-bottom));
      padding: 6px max(8px, calc(50% - 280px)) env(safe-area-inset-bottom);
      display: flex;
      background: rgba(255, 255, 255, 0.94);
      backdrop-filter: blur(14px);
      -webkit-backdrop-filter: blur(14px);
      border-top: 1px solid var(--border);
    }
    a {
      flex: 1;
      display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px;
      color: var(--muted); font-size: 0.72rem; font-weight: 700;
      border-radius: 14px;
    }
    .ico { font-size: 1.35rem; line-height: 1; filter: grayscale(1); opacity: 0.7; transition: transform 0.2s; }
    a.ativo { color: var(--primary); }
    a.ativo .ico { filter: none; opacity: 1; transform: translateY(-1px) scale(1.08); }
  `,
})
export class Casca {
  protected readonly abas = [
    { rota: '/mes', nome: 'Mês', icone: '📅' },
    { rota: '/gastos', nome: 'Gastos', icone: '🧾' },
    { rota: '/historico', nome: 'Histórico', icone: '📊' },
    { rota: '/juntos', nome: 'Juntos', icone: '💞' },
    { rota: '/perfil', nome: 'Perfil', icone: '👤' },
  ];
}
