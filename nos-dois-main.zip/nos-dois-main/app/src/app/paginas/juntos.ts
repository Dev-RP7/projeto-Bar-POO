import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Api } from '../core/api';
import { Avisos } from '../core/avisos';
import { hoje, lerValor, mesCurto, moeda, valorParaCampo } from '../core/formato';
import { Juntos, Meta } from '../core/modelos';
import { SessaoService } from '../core/sessao';

interface FormMeta { id: number | null; nome: string; valor: string; prazo: string; }
interface FormDeposito { meta: Meta; valor: string; data: string; }

/** Tela "Juntos": total guardado, metas com progresso, depósitos e ideias para a sobra. */
@Component({
  selector: 'app-juntos',
  imports: [FormsModule],
  template: `
    <main class="pagina">
      <header class="cabecalho"><h1>Juntos</h1></header>

      @if (dados(); as d) {
        <section class="card destaque">
          <p class="rotulo">Total guardado</p>
          <p class="valor-grande">{{ moeda(d.totalGuardado) }}</p>
          <p class="muted pequeno">Disponível para guardar este mês: <strong [class.negativo]="d.disponivelParaGuardar < 0">{{ moeda(d.disponivelParaGuardar) }}</strong></p>
        </section>

        @if (d.ideias.length) {
          <section class="card ideias">
            <h2>💡 Ideias para a sobra</h2>
            @for (ideia of d.ideias; track ideia) { <p>{{ ideia }}</p> }
          </section>
        }

        @for (m of d.metas; track m.id) {
          <section class="card meta">
            <div class="cabecalho">
              <h2>{{ m.alcancada ? '🎉 ' : '' }}{{ m.nome }}</h2>
              <button class="btn btn-texto" type="button" (click)="editarMeta(m)">Editar</button>
            </div>
            <p class="valores">
              <strong>{{ moeda(m.guardado) }}</strong>
              @if (m.valorAlvo) { <span class="muted"> de {{ moeda(m.valorAlvo) }}</span> }
              @if (m.prazo) { <span class="muted"> · até {{ mesCurto(m.prazo) }}</span> }
            </p>
            @if (m.valorAlvo) {
              <div class="progresso" [attr.aria-label]="m.progresso + '%'"><span [style.width.%]="m.progresso"></span></div>
            }
            @if (m.alcancada) {
              <p class="positivo pequeno"><strong>Meta alcançada!</strong></p>
            } @else if (m.prazoVencido) {
              <p class="negativo pequeno">O prazo passou. Que tal definir um novo?</p>
            } @else if (m.parcelaMensal) {
              <p class="pequeno">Guardando <strong>{{ moeda(m.parcelaMensal) }}</strong> por mês vocês chegam lá.
                @if (m.partesDaParcela.length > 1) {
                  <span class="muted">
                    @for (p of m.partesDaParcela; track p.id; let ultimo = $last) {
                      {{ p.nome.split(' ')[0] }} {{ moeda(p.valor) }}{{ ultimo ? '' : ' · ' }}
                    }
                  </span>
                }
              </p>
            }
            <div class="acoes">
              <button class="btn btn-primario" type="button" (click)="guardar(m)">Guardar</button>
              @if (m.depositos.length) {
                <button class="btn btn-sec" type="button" (click)="alternar(m.id)">{{ aberta() === m.id ? 'Ocultar' : 'Depósitos (' + m.depositos.length + ')' }}</button>
              }
            </div>
            @if (aberta() === m.id) {
              <div class="lista">
                @for (dep of m.depositos; track dep.id) {
                  <div class="item">
                    <span class="texto"><strong>{{ moeda(dep.valor) }}</strong><small>{{ dataBr(dep.data) }} · {{ dep.criadoPorNome }}</small></span>
                    <button class="btn btn-texto" type="button" (click)="excluirDeposito(m, dep.id)" aria-label="Excluir depósito">Excluir</button>
                  </div>
                }
              </div>
            }
          </section>
        } @empty {
          <div class="vazio"><span class="emoji">🎯</span>Crie a primeira meta de vocês: uma viagem, a reserva de emergência, um sonho.</div>
        }
      } @else {
        <p class="carregando">Carregando…</p>
      }

      <button class="fab" type="button" (click)="novaMeta()" aria-label="Nova meta">+</button>
    </main>

    @if (formMeta(); as f) {
      <div class="fundo-sheet" (click)="fechar()">
        <form class="sheet form" (click)="$event.stopPropagation()" (ngSubmit)="salvarMeta()">
          <h2>{{ f.id ? 'Editar meta' : 'Nova meta' }}</h2>
          <div class="campo">
            <label for="nome">Nome</label>
            <input id="nome" name="nome" maxlength="80" placeholder="Ex.: Viagem de férias" [(ngModel)]="f.nome" required autofocus>
          </div>
          <div class="campo">
            <label for="valor">Quanto querem juntar (opcional)</label>
            <input id="valor" name="valor" inputmode="decimal" placeholder="0,00" [(ngModel)]="f.valor">
          </div>
          <div class="campo">
            <label for="prazo">Até quando (opcional)</label>
            <input id="prazo" name="prazo" type="month" [(ngModel)]="f.prazo">
            <span class="dica">Com valor e prazo, calculamos quanto guardar por mês.</span>
          </div>
          <button class="btn btn-primario btn-bloco" type="submit" [disabled]="salvando()">Salvar</button>
          @if (f.id) {
            <button class="btn btn-perigo btn-bloco" type="button" (click)="excluirMeta(f.id)" [disabled]="salvando()">Excluir meta</button>
            <small class="muted centro">Excluir a meta devolve o valor guardado para a sobra.</small>
          }
        </form>
      </div>
    }

    @if (formDeposito(); as f) {
      <div class="fundo-sheet" (click)="fechar()">
        <form class="sheet form" (click)="$event.stopPropagation()" (ngSubmit)="salvarDeposito()">
          <h2>Guardar em "{{ f.meta.nome }}"</h2>
          <div class="campo">
            <label for="dep-valor">Valor (R$)</label>
            <input id="dep-valor" name="valor" inputmode="decimal" placeholder="0,00" [(ngModel)]="f.valor" required autofocus>
            @if (f.meta.parcelaMensal) { <span class="dica">Parcela do mês: {{ moeda(f.meta.parcelaMensal) }}</span> }
          </div>
          <div class="campo">
            <label for="dep-data">Data</label>
            <input id="dep-data" name="data" type="date" [(ngModel)]="f.data" required>
          </div>
          <button class="btn btn-primario btn-bloco" type="submit" [disabled]="salvando()">Guardar</button>
        </form>
      </div>
    }
  `,
  styles: `
    .destaque { background: linear-gradient(135deg, #fff 0%, var(--p1-soft) 100%); }
    .ideias p { color: var(--muted); }
    .ideias p + p { margin-top: 8px; }
    .meta h2 { margin: 0; }
    .valores { margin: 6px 0 10px; }
    .meta .progresso { margin-bottom: 10px; }
    .acoes { display: flex; gap: 8px; margin-top: 12px; }
    .acoes .btn { flex: 1; }
  `,
})
export class JuntosPagina {
  private readonly api = inject(Api);
  private readonly avisos = inject(Avisos);
  protected readonly sessao = inject(SessaoService);

  protected readonly dados = signal<Juntos | null>(null);
  protected readonly aberta = signal<number | null>(null);
  protected readonly formMeta = signal<FormMeta | null>(null);
  protected readonly formDeposito = signal<FormDeposito | null>(null);
  protected readonly salvando = signal(false);

  protected readonly moeda = moeda;
  protected readonly mesCurto = mesCurto;

  constructor() {
    this.carregar();
  }

  carregar(): void {
    this.api.juntos().subscribe({ next: (d) => this.dados.set(d), error: (e) => this.avisos.erro(e) });
  }

  dataBr(data: string): string {
    const [a, m, d] = data.split('-');
    return `${d}/${m}/${a}`;
  }

  alternar(id: number): void {
    this.aberta.set(this.aberta() === id ? null : id);
  }

  novaMeta(): void {
    this.formMeta.set({ id: null, nome: '', valor: '', prazo: '' });
  }

  editarMeta(m: Meta): void {
    this.formMeta.set({ id: m.id, nome: m.nome, valor: valorParaCampo(m.valorAlvo), prazo: m.prazo ?? '' });
  }

  guardar(m: Meta): void {
    this.formDeposito.set({ meta: m, valor: valorParaCampo(m.parcelaMensal), data: hoje() });
  }

  fechar(): void {
    if (this.salvando()) return;
    this.formMeta.set(null);
    this.formDeposito.set(null);
  }

  salvarMeta(): void {
    const f = this.formMeta();
    if (!f) return;
    if (!f.nome.trim()) return this.avisos.mostrar('Dê um nome à meta.', true);
    const valor = f.valor.trim() ? lerValor(f.valor) : null;
    if (f.valor.trim() && (valor === null || valor <= 0)) return this.avisos.mostrar('Valor inválido.', true);
    const prazo = f.prazo || null;

    this.salvando.set(true);
    const pedido = f.id ? this.api.atualizarMeta(f.id, f.nome.trim(), valor, prazo) : this.api.criarMeta(f.nome.trim(), valor, prazo);
    pedido.subscribe({
      next: () => this.concluir(f.id ? 'Meta atualizada.' : 'Meta criada.'),
      error: (e) => this.falhar(e),
    });
  }

  excluirMeta(id: number): void {
    if (!confirm('Excluir esta meta? O valor guardado volta para a sobra.')) return;
    this.salvando.set(true);
    this.api.excluirMeta(id).subscribe({ next: () => this.concluir('Meta excluída.'), error: (e) => this.falhar(e) });
  }

  salvarDeposito(): void {
    const f = this.formDeposito();
    if (!f) return;
    const valor = lerValor(f.valor);
    if (valor === null || valor <= 0) return this.avisos.mostrar('Digite um valor maior que zero.', true);
    this.salvando.set(true);
    this.api.depositar(f.meta.id, valor, f.data || null).subscribe({
      next: () => this.concluir(`Guardado ${moeda(valor)} em "${f.meta.nome}".`),
      error: (e) => this.falhar(e),
    });
  }

  excluirDeposito(m: Meta, depositoId: number): void {
    if (!confirm('Excluir este depósito?')) return;
    this.api.excluirDeposito(m.id, depositoId).subscribe({
      next: () => {
        this.avisos.mostrar('Depósito excluído.');
        this.carregar();
      },
      error: (e) => this.avisos.erro(e),
    });
  }

  private concluir(mensagem: string): void {
    this.salvando.set(false);
    this.formMeta.set(null);
    this.formDeposito.set(null);
    this.avisos.mostrar(mensagem);
    this.carregar();
  }

  private falhar(e: unknown): void {
    this.salvando.set(false);
    this.avisos.erro(e);
  }
}
