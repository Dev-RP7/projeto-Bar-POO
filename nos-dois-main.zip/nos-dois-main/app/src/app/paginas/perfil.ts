import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Api } from '../core/api';
import { Avisos } from '../core/avisos';
import { iniciais } from '../core/formato';
import { RegraDivisao } from '../core/modelos';
import { SessaoService } from '../core/sessao';

/** Perfil: dados da pessoa, convite para o par, regra de divisão, senha, backup e sair. */
@Component({
  selector: 'app-perfil',
  imports: [FormsModule],
  template: `
    <main class="pagina">
      <header class="cabecalho"><h1>Perfil</h1></header>

      @if (sessao.perfil(); as p) {
        <!-- Eu -->
        <section class="card eu">
          <span class="avatar grande" [class.p2]="meuIndice() === 1">{{ iniciais(p.nome) }}</span>
          @if (editandoNome()) {
            <form class="form" style="flex: 1" (ngSubmit)="salvarNome()">
              <div class="campo"><input name="nome" maxlength="80" [(ngModel)]="nome" aria-label="Seu nome" autofocus></div>
              <div class="linha-botoes">
                <button class="btn btn-primario" type="submit">Salvar</button>
                <button class="btn btn-sec" type="button" (click)="editandoNome.set(false)">Cancelar</button>
              </div>
            </form>
          } @else {
            <div style="flex: 1; min-width: 0">
              <strong class="nome">{{ p.nome }}</strong>
              <small class="muted">{{ p.email }}</small>
            </div>
            <button class="btn btn-texto" type="button" (click)="editarNome(p.nome)">Editar</button>
          }
        </section>

        <!-- Seu par -->
        @if (sessao.parceiro(); as par) {
          <section class="card">
            <h2>Seu par</h2>
            <div class="eu" style="padding: 0">
              <span class="avatar" [class.p2]="meuIndice() === 0">{{ iniciais(par.nome) }}</span>
              <div style="flex: 1"><strong>{{ par.nome }}</strong><br><small class="muted">Vocês compartilham o mês, os gastos e as metas 💞</small></div>
            </div>
          </section>
        } @else {
          <section class="card convite">
            <h2>💌 Convide seu par</h2>
            <p class="muted pequeno">Cada um usa a própria conta. Envie o link: a outra pessoa cria a conta dela (ou entra) e aceita o convite. A partir daí, os dois veem e registram tudo.</p>
            @if (p.convite; as c) {
              <div class="codigo" aria-label="Código do convite">{{ c.codigo }}</div>
              <div class="linha-botoes">
                <button class="btn btn-primario" type="button" (click)="compartilhar(c.link, c.codigo)">Compartilhar</button>
                <button class="btn btn-sec" type="button" (click)="copiar(c.link)">Copiar link</button>
              </div>
            }
          </section>

          <section class="card">
            <h2>Recebeu um convite?</h2>
            <form class="aceitar" (ngSubmit)="aceitar()">
              <div class="campo" style="flex: 1">
                <input name="codigo" maxlength="6" placeholder="Código de 6 letras" autocapitalize="characters"
                       [(ngModel)]="codigoRecebido" aria-label="Código do convite">
              </div>
              <button class="btn btn-primario" type="submit" [disabled]="codigoRecebido.trim().length !== 6 || ocupado()">Aceitar</button>
            </form>
            <small class="muted">Seus gastos, rendas e metas vão junto para o casal.</small>
          </section>
        }

        <!-- Divisão -->
        <section class="card">
          <h2>Divisão das contas do casal</h2>
          <div class="segmento" role="radiogroup">
            <button type="button" role="radio" [class.ativo]="p.regraDivisao === 'PROPORCIONAL'" [attr.aria-checked]="p.regraDivisao === 'PROPORCIONAL'"
                    (click)="regra('PROPORCIONAL')">Proporcional à renda</button>
            <button type="button" role="radio" [class.ativo]="p.regraDivisao === 'IGUAL'" [attr.aria-checked]="p.regraDivisao === 'IGUAL'"
                    (click)="regra('IGUAL')">Metade para cada</button>
          </div>
          <p class="muted pequeno" style="margin-top: 10px">
            {{ p.regraDivisao === 'PROPORCIONAL'
              ? 'Quem ganha mais paga uma parte maior. Ex.: com rendas de R$ 5.000 e R$ 3.000, um aluguel de R$ 1.600 fica R$ 1.000 e R$ 600.'
              : 'As contas do casal são divididas ao meio, independente da renda.' }}
          </p>
        </section>

        <!-- Conta -->
        <section class="card lista-acoes">
          <h2>Conta</h2>
          <button class="item" type="button" (click)="abrirSenha()"><span class="icone">🔒</span><span class="texto"><strong>Trocar senha</strong></span><span class="muted">›</span></button>
          <button class="item" type="button" (click)="baixarBackup()"><span class="icone">💾</span><span class="texto"><strong>Baixar backup</strong><small>Todos os dados do casal em um arquivo</small></span><span class="muted">›</span></button>
          @if (sessao.parceiro()) {
            <button class="item" type="button" (click)="sairDoCasal()"><span class="icone">💔</span><span class="texto"><strong>Desconectar do casal</strong><small>Você leva sua renda e seus gastos individuais</small></span><span class="muted">›</span></button>
          }
          <button class="item" type="button" (click)="sair()"><span class="icone">🚪</span><span class="texto"><strong class="negativo">Sair da conta</strong></span></button>
        </section>
      }
    </main>

    @if (trocandoSenha()) {
      <div class="fundo-sheet" (click)="trocandoSenha.set(false)">
        <form class="sheet form" (click)="$event.stopPropagation()" (ngSubmit)="salvarSenha()">
          <h2>Trocar senha</h2>
          <div class="campo"><label for="atual">Senha atual</label><input id="atual" name="atual" type="password" autocomplete="current-password" [(ngModel)]="senhaAtual" required></div>
          <div class="campo"><label for="nova">Nova senha</label><input id="nova" name="nova" type="password" autocomplete="new-password" [(ngModel)]="novaSenha" required minlength="8"><span class="dica">Pelo menos 8 caracteres. Os outros aparelhos serão desconectados.</span></div>
          <button class="btn btn-primario btn-bloco" type="submit" [disabled]="ocupado()">Salvar</button>
        </form>
      </div>
    }
  `,
  styles: `
    .eu { display: flex; align-items: center; gap: 14px; }
    .avatar.grande { width: 56px; height: 56px; font-size: 1.2rem; }
    .nome { display: block; font-size: 1.15rem; font-weight: 800; }
    .convite { background: linear-gradient(135deg, #fff 0%, var(--p1-soft) 100%); }
    .codigo {
      margin: 14px 0; padding: 14px; text-align: center;
      font-size: 2rem; font-weight: 800; letter-spacing: 0.3em;
      background: var(--surface); border: 2px dashed #f2b8be; border-radius: 16px;
    }
    .linha-botoes { display: flex; gap: 8px; }
    .linha-botoes .btn { flex: 1; }
    .aceitar { display: flex; gap: 8px; margin-bottom: 6px; }
    .aceitar input { text-transform: uppercase; letter-spacing: 0.2em; font-weight: 800; }
    .aceitar input::placeholder { text-transform: none; letter-spacing: normal; font-weight: 400; }
    .lista-acoes .item .texto small { display: block; }
  `,
})
export class PerfilPagina {
  private readonly api = inject(Api);
  private readonly avisos = inject(Avisos);
  protected readonly sessao = inject(SessaoService);

  protected readonly editandoNome = signal(false);
  protected readonly trocandoSenha = signal(false);
  protected readonly ocupado = signal(false);
  protected readonly iniciais = iniciais;
  protected readonly meuIndice = computed(() => this.sessao.perfil()?.pessoas.findIndex((p) => p.eu) ?? 0);

  nome = '';
  codigoRecebido = '';
  senhaAtual = '';
  novaSenha = '';

  constructor() {
    // Busca o perfil atualizado (a outra pessoa pode ter aceitado o convite).
    this.api.perfil().subscribe({ error: () => {} });
  }

  editarNome(atual: string): void {
    this.nome = atual;
    this.editandoNome.set(true);
  }

  salvarNome(): void {
    if (!this.nome.trim()) return;
    this.api.alterarNome(this.nome.trim()).subscribe({
      next: () => {
        this.editandoNome.set(false);
        this.avisos.mostrar('Nome atualizado.');
      },
      error: (e) => this.avisos.erro(e),
    });
  }

  async compartilhar(link: string, codigo: string): Promise<void> {
    const texto = `Vamos organizar nossas finanças juntos no Nós Dois? Meu código de convite é ${codigo}.`;
    if (navigator.share) {
      try {
        await navigator.share({ title: 'Nós Dois', text: texto, url: link });
        return;
      } catch {
        // A pessoa cancelou o compartilhamento; não faz nada.
        return;
      }
    }
    this.copiar(link);
  }

  async copiar(link: string): Promise<void> {
    try {
      await navigator.clipboard.writeText(link);
      this.avisos.mostrar('Link copiado. Agora é só colar na conversa.');
    } catch {
      this.avisos.mostrar(link);
    }
  }

  aceitar(): void {
    this.ocupado.set(true);
    this.api.aceitarConvite(this.codigoRecebido.trim().toUpperCase()).subscribe({
      next: (p) => {
        this.ocupado.set(false);
        this.codigoRecebido = '';
        const outro = p.pessoas.find((x) => !x.eu);
        this.avisos.mostrar(outro ? `Pronto! Você e ${outro.nome} estão conectados.` : 'Convite aceito.');
      },
      error: (e) => {
        this.ocupado.set(false);
        this.avisos.erro(e);
      },
    });
  }

  regra(r: RegraDivisao): void {
    if (this.sessao.perfil()?.regraDivisao === r) return;
    this.api.alterarRegra(r).subscribe({
      next: () => this.avisos.mostrar('Regra de divisão atualizada.'),
      error: (e) => this.avisos.erro(e),
    });
  }

  abrirSenha(): void {
    this.senhaAtual = '';
    this.novaSenha = '';
    this.trocandoSenha.set(true);
  }

  salvarSenha(): void {
    if (this.novaSenha.length < 8) return this.avisos.mostrar('A nova senha precisa de pelo menos 8 caracteres.', true);
    this.ocupado.set(true);
    this.api.trocarSenha(this.senhaAtual, this.novaSenha).subscribe({
      next: () => {
        this.ocupado.set(false);
        this.trocandoSenha.set(false);
        this.avisos.mostrar('Senha alterada. Entre de novo.');
        this.sessao.encerrarLocal();
      },
      error: (e) => {
        this.ocupado.set(false);
        this.avisos.erro(e);
      },
    });
  }

  baixarBackup(): void {
    this.api.backup().subscribe({
      next: (dados) => {
        const blob = new Blob([JSON.stringify(dados, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `nos-dois-backup-${new Date().toISOString().slice(0, 10)}.json`;
        a.click();
        URL.revokeObjectURL(url);
      },
      error: (e) => this.avisos.erro(e),
    });
  }

  sairDoCasal(): void {
    const par = this.sessao.parceiro();
    if (!par || !confirm(`Desconectar de ${par.nome}? Os gastos do casal e as metas ficam com ${par.nome}; você leva sua renda e seus gastos individuais.`)) return;
    this.api.sairDoCasal().subscribe({
      next: () => this.avisos.mostrar('Você saiu do casal.'),
      error: (e) => this.avisos.erro(e),
    });
  }

  sair(): void {
    if (confirm('Sair da conta neste aparelho?')) this.sessao.sair();
  }
}
