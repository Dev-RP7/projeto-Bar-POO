import { Component, inject, input, OnInit, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { Api } from '../core/api';
import { Avisos, mensagemDeErro } from '../core/avisos';
import { ConvitePublico } from '../core/modelos';
import { SessaoService } from '../core/sessao';

/**
 * Link de convite (/convite/CODIGO). Quem já tem conta aceita aqui; quem não tem
 * cria a conta ou entra e volta para esta mesma tela.
 */
@Component({
  selector: 'app-convite',
  imports: [RouterLink],
  template: `
    <main class="entrada">
      <div class="marca">
        <div class="logo">💌</div>
        @if (convite(); as c) {
          <h1>{{ c.nomeDeQuemConvidou ? c.nomeDeQuemConvidou + ' te convidou' : 'Você foi convidado(a)' }}</h1>
          <p>Para cuidarem juntos das finanças no Nós Dois.</p>
        } @else if (erro()) {
          <h1>Convite inválido</h1>
          <p>{{ erro() }}</p>
        } @else {
          <h1>Carregando convite…</h1>
        }
      </div>

      @if (convite(); as c) {
        <div class="card form">
          @if (!c.disponivel) {
            <p class="centro">Este convite já foi usado. Peça um novo link.</p>
            <a class="btn btn-sec btn-bloco" routerLink="/mes">Ir para o app</a>
          } @else if (sessao.logado()) {
            <p class="centro">Você vai entrar como <strong>{{ sessao.perfil()?.nome }}</strong>.
              Seus gastos, rendas e metas vão junto e passam a ser vistos pelos dois.</p>
            <button class="btn btn-primario btn-bloco" (click)="aceitar(c.codigo)" [disabled]="aceitando()">
              {{ aceitando() ? 'Conectando…' : 'Aceitar convite' }}
            </button>
            <a class="btn btn-texto" routerLink="/mes">Agora não</a>
          } @else {
            <p class="centro">Cada um usa a própria conta. Crie a sua ou entre para aceitar.</p>
            <a class="btn btn-primario btn-bloco" routerLink="/criar-conta" [queryParams]="{ voltar: aqui() }">Criar minha conta</a>
            <a class="btn btn-sec btn-bloco" routerLink="/entrar" [queryParams]="{ voltar: aqui() }">Já tenho conta</a>
          }
        </div>
      }
    </main>
  `,
})
export class ConvitePagina implements OnInit {
  private readonly api = inject(Api);
  private readonly router = inject(Router);
  private readonly avisos = inject(Avisos);
  protected readonly sessao = inject(SessaoService);

  readonly codigo = input.required<string>();

  protected readonly convite = signal<ConvitePublico | null>(null);
  protected readonly erro = signal('');
  protected readonly aceitando = signal(false);

  ngOnInit(): void {
    this.api.convite(this.codigo()).subscribe({
      next: (c) => this.convite.set(c),
      error: (e) => this.erro.set(mensagemDeErro(e)),
    });
  }

  aqui(): string {
    return `/convite/${this.codigo()}`;
  }

  aceitar(codigo: string): void {
    this.aceitando.set(true);
    this.api.aceitarConvite(codigo).subscribe({
      next: (p) => {
        const outro = p.pessoas.find((x) => !x.eu);
        this.avisos.mostrar(outro ? `Pronto! Você e ${outro.nome} estão conectados.` : 'Convite aceito.');
        this.router.navigateByUrl('/mes');
      },
      error: (e) => {
        this.aceitando.set(false);
        this.avisos.erro(e);
      },
    });
  }
}
