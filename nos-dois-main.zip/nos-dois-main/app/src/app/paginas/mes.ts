import { Component, computed, effect, inject, signal, untracked } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { Api } from '../core/api';
import { Avisos } from '../core/avisos';
import { iniciais, lerValor, mesAtual, moeda, valorParaCampo } from '../core/formato';
import { PessoaMes, ResumoMes } from '../core/modelos';
import { SessaoService } from '../core/sessao';
import { SeletorMes } from '../componentes/seletor-mes';

/** Tela "Mês": sobra do casal, quanto cada um paga, contas do casal e o que dá para guardar. */
@Component({
  selector: 'app-mes',
  imports: [FormsModule, RouterLink, SeletorMes],
  template: `
    <main class="pagina">
      <header class="cabecalho">
        <h1>Olá, {{ primeiroNome() }}</h1>
      </header>
      <app-seletor-mes [(mes)]="mes" />

      @if (!sessao.parceiro()) {
        <a class="card convite" routerLink="/perfil">
          <span class="emoji">💌</span>
          <span><strong>Convide seu par</strong><br><small class="muted">Os dois veem e registram tudo, cada um no próprio celular.</small></span>
        </a>
      }

      @if (resumo(); as r) {
        <!-- Sobra do casal -->
        <section class="card">
          <p class="rotulo">{{ r.pessoas.length > 1 ? 'Sobra do casal' : 'Sua sobra' }}</p>
          <p class="valor-grande" [class.negativo]="r.sobraCasal < 0">{{ moeda(r.sobraCasal) }}</p>
          <p class="muted pequeno">Entrou {{ moeda(r.totalRendas) }} · saiu {{ moeda(r.totalGastos) }}</p>
          @if (r.pessoas.length > 1 && somaSobrasPositivas() > 0) {
            <div class="barra-divisao" style="margin-top: 14px" aria-hidden="true">
              @for (p of r.pessoas; track p.id; let i = $index) {
                @if (p.sobra > 0) { <span [class]="'p' + (i + 1)" [style.flex-grow]="p.sobra"></span> }
              }
            </div>
            <div class="legenda">
              @for (p of r.pessoas; track p.id; let i = $index) {
                <span><i [class.p2]="i === 1"></i>{{ p.nome }}: {{ moeda(p.sobra) }}</span>
              }
            </div>
          }
        </section>

        <!-- Uma pessoa por cartão -->
        @for (p of r.pessoas; track p.id; let i = $index) {
          <section class="card">
            <div class="pessoa">
              <span class="avatar" [class.p2]="i === 1">{{ iniciais(p.nome) }}</span>
              <h2>{{ p.eu ? 'Você' : p.nome }}</h2>
            </div>

            <div class="linha">
              <span>Renda
                @if (p.rendaRepetida) { <small class="muted">(repetida do mês anterior)</small> }
              </span>
              @if (editandoRenda() && p.eu) {
                <form class="editar-renda" (ngSubmit)="salvarRenda()">
                  <input name="renda" inputmode="decimal" [(ngModel)]="rendaTexto" aria-label="Sua renda" autofocus>
                  <button class="btn btn-primario" type="submit" [disabled]="salvando()">OK</button>
                </form>
              } @else {
                <strong>{{ moeda(p.renda) }}
                  @if (p.eu) { <button class="btn btn-texto" type="button" (click)="editarRenda(p)">Editar</button> }
                </strong>
              }
            </div>
            @if (r.pessoas.length > 1) {
              <div class="linha"><span>Parte das contas do casal</span><strong>{{ moeda(p.parteContasCasal) }}</strong></div>
            } @else {
              <div class="linha"><span>Contas da casa</span><strong>{{ moeda(p.parteContasCasal) }}</strong></div>
            }
            <div class="linha"><span>Contas só {{ p.eu ? 'suas' : 'de ' + p.nome }}</span><strong>{{ moeda(p.contasIndividuais) }}</strong></div>
            <div class="linha"><span>Total que paga</span><strong>{{ moeda(p.totalPaga) }}</strong></div>
            <div class="linha"><span>Sobra</span><strong [class.positivo]="p.sobra > 0" [class.negativo]="p.sobra < 0">{{ moeda(p.sobra) }}</strong></div>
          </section>
        }

        <!-- Contas do casal -->
        @if (r.pessoas.length > 1) {
          <section class="card">
            <div class="cabecalho">
              <h2>Contas do casal</h2>
              <a class="pequeno" routerLink="/perfil">{{ r.regraDivisao === 'PROPORCIONAL' ? 'Proporcional à renda' : 'Metade para cada' }}</a>
            </div>
            <p class="valor-grande" style="font-size: 1.6rem">{{ moeda(r.contasCasal) }}</p>
            @if (r.contasCasal > 0) {
              <div class="barra-divisao" style="margin-top: 12px" aria-hidden="true">
                @for (p of r.pessoas; track p.id; let i = $index) {
                  <span [class]="'p' + (i + 1)" [style.flex-grow]="p.parteContasCasal"></span>
                }
              </div>
              <div class="legenda">
                @for (p of r.pessoas; track p.id; let i = $index) {
                  <span><i [class.p2]="i === 1"></i>{{ p.nome }}: {{ moeda(p.parteContasCasal) }}</span>
                }
              </div>
            }
          </section>
        }

        <!-- Guardar -->
        <a class="card guardar" routerLink="/juntos">
          <div>
            <p class="rotulo">Disponível para guardar</p>
            <p class="valor-grande" style="font-size: 1.6rem" [class.negativo]="r.disponivelParaGuardar < 0">{{ moeda(r.disponivelParaGuardar) }}</p>
            @if (r.depositosNoMes > 0) { <small class="muted">Já guardado este mês: {{ moeda(r.depositosNoMes) }}</small> }
          </div>
          <span aria-hidden="true">›</span>
        </a>

        <!-- Por categoria -->
        @if (r.porCategoria.length) {
          <section class="card">
            <h2>Para onde foi o dinheiro</h2>
            @for (c of r.porCategoria; track c.categoria) {
              <div class="categoria">
                <div class="linha" style="padding-bottom: 4px"><span>{{ c.rotulo }}</span><strong>{{ moeda(c.total) }}</strong></div>
                <div class="progresso"><span [style.width.%]="(c.total / r.totalGastos) * 100" style="background: var(--casal)"></span></div>
              </div>
            }
          </section>
        }
      } @else if (carregando()) {
        <p class="carregando">Carregando…</p>
      }
    </main>
  `,
  styles: `
    .convite { display: flex; gap: 14px; align-items: center; color: var(--text); font-weight: 400; background: var(--p1-soft); border-color: #f8d3d7; }
    .convite .emoji { font-size: 1.8rem; }
    .pessoa { display: flex; align-items: center; gap: 10px; margin-bottom: 4px; }
    .pessoa h2 { margin: 0; }
    .editar-renda { display: flex; gap: 6px; }
    .editar-renda input { width: 120px; min-height: 40px; padding: 6px 10px; border: 1px solid var(--border); border-radius: 10px; font-size: 16px; }
    .editar-renda .btn { min-height: 40px; padding: 0 14px; }
    .guardar { display: flex; align-items: center; justify-content: space-between; color: var(--text); font-weight: 400; }
    .guardar > span { font-size: 1.8rem; color: var(--muted); }
    .categoria + .categoria { margin-top: 10px; }
    .categoria .linha { border: none; }
  `,
})
export class MesPagina {
  private readonly api = inject(Api);
  private readonly avisos = inject(Avisos);
  protected readonly sessao = inject(SessaoService);

  protected readonly mes = signal(mesAtual());
  protected readonly resumo = signal<ResumoMes | null>(null);
  protected readonly carregando = signal(false);
  protected readonly editandoRenda = signal(false);
  protected readonly salvando = signal(false);
  rendaTexto = '';

  protected readonly moeda = moeda;
  protected readonly iniciais = iniciais;
  protected readonly primeiroNome = computed(() => (this.sessao.perfil()?.nome ?? '').split(' ')[0]);
  protected readonly somaSobrasPositivas = computed(() =>
    (this.resumo()?.pessoas ?? []).reduce((s, p) => s + Math.max(0, p.sobra), 0));

  constructor() {
    // Recarrega sempre que o mês muda.
    effect(() => {
      const mes = this.mes();
      untracked(() => this.carregar(mes));
    });
    // Atualiza o perfil (a outra pessoa pode ter aceitado o convite).
    this.api.perfil().subscribe({ error: () => {} });
  }

  carregar(mes: string): void {
    this.carregando.set(true);
    this.editandoRenda.set(false);
    this.api.mes(mes).subscribe({
      next: (r) => {
        this.resumo.set(r);
        this.carregando.set(false);
      },
      error: (e) => {
        this.carregando.set(false);
        this.avisos.erro(e);
      },
    });
  }

  editarRenda(p: PessoaMes): void {
    this.rendaTexto = valorParaCampo(p.renda);
    this.editandoRenda.set(true);
  }

  salvarRenda(): void {
    const valor = lerValor(this.rendaTexto);
    if (valor === null || valor < 0) {
      this.avisos.mostrar('Digite um valor válido, como 3500,00.', true);
      return;
    }
    this.salvando.set(true);
    this.api.definirRenda(this.mes(), valor).subscribe({
      next: (r) => {
        this.resumo.set(r);
        this.salvando.set(false);
        this.editandoRenda.set(false);
        this.avisos.mostrar('Renda salva. Os próximos meses repetem este valor até você mudar.');
      },
      error: (e) => {
        this.salvando.set(false);
        this.avisos.erro(e);
      },
    });
  }
}
