import { Component, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { Api } from '../../core/api';
import { mensagemDeErro } from '../../core/avisos';

/** Cada pessoa cria a própria conta. O convite para a outra pessoa fica no perfil, depois. */
@Component({
  selector: 'app-criar-conta',
  imports: [FormsModule, RouterLink],
  template: `
    <main class="entrada">
      <div class="marca">
        <div class="logo">💞</div>
        <h1>Criar conta</h1>
        <p>Comece sozinho(a). Depois é só convidar seu par pelo perfil.</p>
      </div>

      <form class="card form" (ngSubmit)="criar()">
        <div class="campo">
          <label for="nome">Seu nome</label>
          <input id="nome" name="nome" autocomplete="given-name" [(ngModel)]="nome" required maxlength="80">
        </div>
        <div class="campo">
          <label for="email">E-mail</label>
          <input id="email" name="email" type="email" autocomplete="email" inputmode="email" [(ngModel)]="email" required>
        </div>
        <div class="campo">
          <label for="senha">Senha</label>
          <input id="senha" name="senha" type="password" autocomplete="new-password" [(ngModel)]="senha" required minlength="8">
          <span class="dica">Pelo menos 8 caracteres.</span>
        </div>
        <div class="campo">
          <label for="confirmar">Confirme a senha</label>
          <input id="confirmar" name="confirmar" type="password" autocomplete="new-password" [(ngModel)]="confirmar" required>
        </div>
        @if (erro()) { <p class="erro-form" role="alert">{{ erro() }}</p> }
        <button class="btn btn-primario btn-bloco" type="submit" [disabled]="carregando()">
          {{ carregando() ? 'Criando…' : 'Criar conta' }}
        </button>
      </form>

      <p class="rodape">Já tem conta? <a routerLink="/entrar" [queryParams]="{ voltar: voltar() || null }">Entrar</a></p>
    </main>
  `,
})
export class CriarConta {
  private readonly api = inject(Api);
  private readonly router = inject(Router);

  readonly voltar = input<string>();

  nome = '';
  email = '';
  senha = '';
  confirmar = '';
  protected readonly carregando = signal(false);
  protected readonly erro = signal('');

  criar(): void {
    if (!this.nome.trim() || !this.email.trim()) return this.erro.set('Preencha nome e e-mail.');
    if (this.senha.length < 8) return this.erro.set('A senha deve ter pelo menos 8 caracteres.');
    if (this.senha !== this.confirmar) return this.erro.set('As senhas não são iguais.');

    this.carregando.set(true);
    this.erro.set('');
    const email = this.email.trim();
    this.api.cadastrar(this.nome.trim(), email, this.senha).subscribe({
      next: () => this.router.navigate(['/verificar'], { queryParams: { email, voltar: this.voltar() || null } }),
      error: (e) => {
        this.carregando.set(false);
        this.erro.set(mensagemDeErro(e));
      },
    });
  }
}
