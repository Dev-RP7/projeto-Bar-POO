import { Component, inject, input, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { Api } from '../../core/api';
import { Avisos, mensagemDeErro } from '../../core/avisos';

/** Recuperar a senha em dois passos: pedir o código e definir a senha nova. */
@Component({
  selector: 'app-esqueci-senha',
  imports: [FormsModule, RouterLink],
  template: `
    <main class="entrada">
      <div class="marca">
        <div class="logo">🔑</div>
        <h1>Recuperar senha</h1>
        <p>{{ etapa() === 'email' ? 'Vamos enviar um código para o seu e-mail.' : 'Digite o código e crie uma senha nova.' }}</p>
      </div>

      @if (etapa() === 'email') {
        <form class="card form" (ngSubmit)="pedirCodigo()">
          <div class="campo">
            <label for="email">E-mail</label>
            <input id="email" name="email" type="email" inputmode="email" autocomplete="email" [(ngModel)]="emailDigitado" required>
          </div>
          @if (erro()) { <p class="erro-form" role="alert">{{ erro() }}</p> }
          <button class="btn btn-primario btn-bloco" type="submit" [disabled]="carregando()">Enviar código</button>
        </form>
      } @else {
        <form class="card form" (ngSubmit)="redefinir()">
          <div class="campo">
            <label for="codigo">Código</label>
            <input id="codigo" name="codigo" class="codigo-input" inputmode="numeric" autocomplete="one-time-code" maxlength="6" [(ngModel)]="codigo" required>
          </div>
          <div class="campo">
            <label for="senha">Nova senha</label>
            <input id="senha" name="senha" type="password" autocomplete="new-password" [(ngModel)]="senha" required minlength="8">
            <span class="dica">Pelo menos 8 caracteres.</span>
          </div>
          @if (erro()) { <p class="erro-form" role="alert">{{ erro() }}</p> }
          <button class="btn btn-primario btn-bloco" type="submit" [disabled]="carregando()">Salvar senha e entrar</button>
        </form>
      }

      <p class="rodape"><a routerLink="/entrar">Voltar para entrar</a></p>
    </main>
  `,
})
export class EsqueciSenha implements OnInit {
  private readonly api = inject(Api);
  private readonly router = inject(Router);
  private readonly avisos = inject(Avisos);

  readonly email = input('');

  emailDigitado = '';
  codigo = '';
  senha = '';
  protected readonly etapa = signal<'email' | 'codigo'>('email');
  protected readonly carregando = signal(false);
  protected readonly erro = signal('');

  ngOnInit(): void {
    this.emailDigitado = this.email() ?? '';
  }

  pedirCodigo(): void {
    if (!this.emailDigitado.trim()) return this.erro.set('Informe seu e-mail.');
    this.carregando.set(true);
    this.erro.set('');
    this.api.esqueciSenha(this.emailDigitado.trim()).subscribe({
      next: (r) => {
        this.carregando.set(false);
        this.avisos.mostrar(r.mensagem);
        this.etapa.set('codigo');
      },
      error: (e) => {
        this.carregando.set(false);
        this.erro.set(mensagemDeErro(e));
      },
    });
  }

  redefinir(): void {
    if (this.senha.length < 8) return this.erro.set('A senha deve ter pelo menos 8 caracteres.');
    this.carregando.set(true);
    this.erro.set('');
    this.api.redefinirSenha(this.emailDigitado.trim(), this.codigo.trim(), this.senha).subscribe({
      next: () => {
        this.avisos.mostrar('Senha alterada.');
        this.router.navigateByUrl('/mes');
      },
      error: (e) => {
        this.carregando.set(false);
        this.erro.set(mensagemDeErro(e));
      },
    });
  }
}
