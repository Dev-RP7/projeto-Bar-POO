import { Component, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { Api } from '../../core/api';
import { codigoDeErro, mensagemDeErro } from '../../core/avisos';

@Component({
  selector: 'app-entrar',
  imports: [FormsModule, RouterLink],
  template: `
    <main class="entrada">
      <div class="marca">
        <div class="logo">💞</div>
        <h1>Nós Dois</h1>
        <p>As finanças de vocês dois, juntas.</p>
      </div>

      <form class="card form" (ngSubmit)="entrar()">
        <div class="campo">
          <label for="email">E-mail</label>
          <input id="email" name="email" type="email" autocomplete="email" inputmode="email" [(ngModel)]="email" required>
        </div>
        <div class="campo">
          <label for="senha">Senha</label>
          <input id="senha" name="senha" type="password" autocomplete="current-password" [(ngModel)]="senha" required>
        </div>
        @if (erro()) { <p class="erro-form" role="alert">{{ erro() }}</p> }
        <button class="btn btn-primario btn-bloco" type="submit" [disabled]="carregando()">
          {{ carregando() ? 'Entrando…' : 'Entrar' }}
        </button>
        <a class="centro pequeno" routerLink="/esqueci-senha" [queryParams]="{ email: email || null }">Esqueci minha senha</a>
      </form>

      <p class="rodape">Ainda não tem conta? <a routerLink="/criar-conta" [queryParams]="{ voltar: voltar() || null }">Criar conta</a></p>
    </main>
  `,
})
export class Entrar {
  private readonly api = inject(Api);
  private readonly router = inject(Router);

  /** Para onde voltar depois de entrar (ex.: um link de convite). */
  readonly voltar = input<string>();

  email = '';
  senha = '';
  protected readonly carregando = signal(false);
  protected readonly erro = signal('');

  entrar(): void {
    if (!this.email || !this.senha) {
      this.erro.set('Preencha e-mail e senha.');
      return;
    }
    this.carregando.set(true);
    this.erro.set('');
    this.api.entrar(this.email.trim(), this.senha).subscribe({
      next: () => this.router.navigateByUrl(this.voltar() || '/mes'),
      error: (e) => {
        this.carregando.set(false);
        if (codigoDeErro(e) === 'EMAIL_NAO_VERIFICADO') {
          this.router.navigate(['/verificar'], { queryParams: { email: this.email.trim(), voltar: this.voltar() || null } });
          return;
        }
        this.erro.set(mensagemDeErro(e));
      },
    });
  }
}
