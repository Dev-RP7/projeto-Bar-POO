import { Component, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { Api } from '../../core/api';
import { Avisos, mensagemDeErro } from '../../core/avisos';

/** Digitar o código de 6 números enviado por e-mail. A conta só fica ativa depois disso. */
@Component({
  selector: 'app-verificar',
  imports: [FormsModule, RouterLink],
  template: `
    <main class="entrada">
      <div class="marca">
        <div class="logo">📬</div>
        <h1>Confirme seu e-mail</h1>
        <p>Enviamos um código de 6 números para <strong>{{ email() }}</strong>.</p>
      </div>

      <form class="card form" (ngSubmit)="confirmar()">
        <div class="campo">
          <label for="codigo">Código</label>
          <input id="codigo" name="codigo" class="codigo-input" inputmode="numeric" autocomplete="one-time-code"
                 maxlength="6" [(ngModel)]="codigo" (ngModelChange)="aoDigitar($event)" required>
        </div>
        @if (erro()) { <p class="erro-form" role="alert">{{ erro() }}</p> }
        <button class="btn btn-primario btn-bloco" type="submit" [disabled]="carregando() || codigo.length !== 6">
          {{ carregando() ? 'Confirmando…' : 'Confirmar' }}
        </button>
        <button class="btn btn-texto" type="button" (click)="reenviar()" [disabled]="reenviando()">
          Não recebeu? Enviar outro código
        </button>
      </form>

      <p class="rodape">Olhe também a caixa de spam. <a routerLink="/entrar">Voltar</a></p>
    </main>
  `,
})
export class Verificar {
  private readonly api = inject(Api);
  private readonly router = inject(Router);
  private readonly avisos = inject(Avisos);

  readonly email = input('');
  readonly voltar = input<string>();

  codigo = '';
  protected readonly carregando = signal(false);
  protected readonly reenviando = signal(false);
  protected readonly erro = signal('');

  aoDigitar(valor: string): void {
    this.codigo = (valor ?? '').replace(/\D/g, '').slice(0, 6);
    if (this.codigo.length === 6 && !this.carregando()) this.confirmar();
  }

  confirmar(): void {
    this.carregando.set(true);
    this.erro.set('');
    this.api.verificar(this.email(), this.codigo).subscribe({
      next: () => {
        this.avisos.mostrar('E-mail confirmado. Bem-vindo(a)!');
        this.router.navigateByUrl(this.voltar() || '/mes');
      },
      error: (e) => {
        this.carregando.set(false);
        this.codigo = '';
        this.erro.set(mensagemDeErro(e));
      },
    });
  }

  reenviar(): void {
    this.reenviando.set(true);
    this.api.reenviarCodigo(this.email()).subscribe({
      next: () => {
        this.reenviando.set(false);
        this.avisos.mostrar('Código reenviado.');
      },
      error: (e) => {
        this.reenviando.set(false);
        this.avisos.erro(e);
      },
    });
  }
}
