import { Component, computed, effect, inject, signal, untracked } from '@angular/core';
import { Api } from '../core/api';
import { Avisos } from '../core/avisos';
import { mesAtual, moeda } from '../core/formato';
import { Historico } from '../core/modelos';
import { SeletorMes } from '../componentes/seletor-mes';

type Visao = 'dia' | 'mes' | 'ano';

/** Tela "Histórico": por dia (de um mês), por mês (de um ano) e por ano. */
@Component({
  selector: 'app-historico',
  imports: [SeletorMes],
  template: `
    <main class="pagina">
      <header class="cabecalho"><h1>Histórico</h1></header>

      <div class="segmento" role="tablist">
        <button type="button" role="tab" [class.ativo]="visao() === 'dia'" (click)="visao.set('dia')">Por dia</button>
        <button type="button" role="tab" [class.ativo]="visao() === 'mes'" (click)="visao.set('mes')">Por mês</button>
        <button type="button" role="tab" [class.ativo]="visao() === 'ano'" (click)="visao.set('ano')">Por ano</button>
      </div>

      @switch (visao()) {
        @case ('dia') { <app-seletor-mes [(mes)]="mes" /> }
        @case ('mes') {
          <div class="seletor-mes">
            <button type="button" (click)="ano.set(ano() - 1)" aria-label="Ano anterior">‹</button>
            <strong>{{ ano() }}</strong>
            <button type="button" (click)="ano.set(ano() + 1)" aria-label="Próximo ano">›</button>
          </div>
        }
      }

      @if (dados(); as h) {
        <section class="card resumo">
          <div><span class="rotulo">Entrou</span><strong>{{ moeda(h.total.entrou) }}</strong></div>
          <div><span class="rotulo">Saiu</span><strong>{{ moeda(h.total.saiu) }}</strong></div>
          <div><span class="rotulo">Sobrou</span><strong [class.negativo]="h.total.sobrou < 0">{{ moeda(h.total.sobrou) }}</strong></div>
          <div><span class="rotulo">Guardado</span><strong class="positivo">{{ moeda(h.total.guardado) }}</strong></div>
        </section>

        <section class="card">
          @for (l of linhasVisiveis(); track l.periodo) {
            <div class="periodo" [class.futuro]="l.futuro">
              <div class="cabecalho"><strong>{{ l.rotulo }}</strong>
                @if (!l.futuro) { <span [class.negativo]="l.sobrou < 0" [class.positivo]="l.sobrou > 0">{{ moeda(l.sobrou) }}</span> }
              </div>
              @if (!l.futuro) {
                <small class="muted">
                  @if (visao() !== 'dia') { Entrou {{ moeda(l.entrou) }} · }
                  Saiu {{ moeda(l.saiu) }}
                  @if (l.guardado > 0) { · Guardado {{ moeda(l.guardado) }} }
                </small>
              }
            </div>
          } @empty {
            <div class="vazio"><span class="emoji">📊</span>Nada registrado neste período.</div>
          }
        </section>
      } @else {
        <p class="carregando">Carregando…</p>
      }
    </main>
  `,
  styles: `
    .resumo { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
    .resumo strong { display: block; font-size: 1.15rem; font-weight: 800; }
    .periodo { padding: 10px 0; }
    .periodo + .periodo { border-top: 1px solid var(--border); }
    .periodo .cabecalho { margin: 0; }
    .periodo.futuro { opacity: 0.4; }
  `,
})
export class HistoricoPagina {
  private readonly api = inject(Api);
  private readonly avisos = inject(Avisos);

  protected readonly visao = signal<Visao>('mes');
  protected readonly mes = signal(mesAtual());
  protected readonly ano = signal(new Date().getFullYear());
  protected readonly dados = signal<Historico | null>(null);
  protected readonly moeda = moeda;

  /**
   * Na visão por mês: sem meses futuros nem os meses vazios antes do primeiro registro,
   * e o mais recente primeiro (no celular, é o que a pessoa procura).
   */
  protected readonly linhasVisiveis = computed(() => {
    const h = this.dados();
    if (!h) return [];
    if (h.tipo !== 'mes') return h.linhas;
    const reais = h.linhas.filter((l) => !l.futuro);
    const primeiro = reais.findIndex((l) => l.entrou !== 0 || l.saiu !== 0 || l.guardado !== 0);
    return primeiro < 0 ? [] : reais.slice(primeiro).reverse();
  });

  constructor() {
    effect(() => {
      const visao = this.visao();
      const mes = this.mes();
      const ano = this.ano();
      untracked(() => this.carregar(visao, mes, ano));
    });
  }

  carregar(visao: Visao, mes: string, ano: number): void {
    this.dados.set(null);
    const pedido = visao === 'dia' ? this.api.historicoDias(mes) : visao === 'mes' ? this.api.historicoMeses(ano) : this.api.historicoAnos();
    pedido.subscribe({ next: (h) => this.dados.set(h), error: (e) => this.avisos.erro(e) });
  }
}
