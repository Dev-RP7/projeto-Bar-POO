import { Component, computed, effect, inject, signal, untracked } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Api } from '../core/api';
import { Avisos } from '../core/avisos';
import { hoje, lerValor, mesAtual, moeda, nomeDia, valorParaCampo } from '../core/formato';
import { CATEGORIAS, Categoria, Gasto, GastosMes, iconeCategoria } from '../core/modelos';
import { SessaoService } from '../core/sessao';
import { SeletorMes } from '../componentes/seletor-mes';

interface FormGasto {
  id: number | null;
  descricao: string;
  valor: string;
  data: string;
  categoria: Categoria;
  donoId: number | null;
}

/** Tela "Gastos": lista do mês por dia e cadastro/edição de gastos. */
@Component({
  selector: 'app-gastos',
  imports: [FormsModule, SeletorMes],
  template: `
    <main class="pagina">
      <header class="cabecalho"><h1>Gastos</h1></header>
      <app-seletor-mes [(mes)]="mes" />

      @if (dados(); as d) {
        <section class="card total">
          <span class="rotulo">Total do mês</span>
          <strong class="valor-grande" style="font-size: 1.6rem">{{ moeda(d.total) }}</strong>
        </section>

        @for (dia of d.dias; track dia.data) {
          <section class="card">
            <div class="cabecalho dia">
              <span>{{ nomeDia(dia.data) }}</span>
              <span class="muted">{{ moeda(dia.total) }}</span>
            </div>
            <div class="lista">
              @for (g of dia.gastos; track g.id) {
                <button class="item" type="button" (click)="editar(g)">
                  <span class="icone" aria-hidden="true">{{ icone(g.categoria) }}</span>
                  <span class="texto">
                    <strong>{{ g.descricao }}</strong>
                    <small>{{ g.categoriaRotulo }} ·
                      <span class="tag" [class]="classeDono(g.donoId)">{{ rotuloDono(g) }}</span>
                    </small>
                  </span>
                  <span class="valor">{{ moeda(g.valor) }}</span>
                </button>
              }
            </div>
          </section>
        } @empty {
          <div class="vazio"><span class="emoji">🧾</span>Nenhum gasto neste mês. Toque em + para lançar o primeiro.</div>
        }
      } @else {
        <p class="carregando">Carregando…</p>
      }

      <button class="fab" type="button" (click)="novo()" aria-label="Lançar gasto">+</button>
    </main>

    @if (form(); as f) {
      <div class="fundo-sheet" (click)="fechar()">
        <form class="sheet form" (click)="$event.stopPropagation()" (ngSubmit)="salvar()">
          <h2>{{ f.id ? 'Editar gasto' : 'Novo gasto' }}</h2>
          <div class="campo">
            <label for="valor">Valor (R$)</label>
            <input id="valor" name="valor" inputmode="decimal" placeholder="0,00" [(ngModel)]="f.valor" required autofocus>
          </div>
          <div class="campo">
            <label for="descricao">Descrição</label>
            <input id="descricao" name="descricao" maxlength="120" placeholder="Ex.: Mercado do mês" [(ngModel)]="f.descricao" required>
          </div>
          <div class="campo">
            <label>De quem é</label>
            <div class="segmento" role="radiogroup">
              @for (op of donos(); track op.id) {
                <button type="button" role="radio" [attr.aria-checked]="f.donoId === op.id"
                        [class.ativo]="f.donoId === op.id" (click)="f.donoId = op.id">{{ op.nome }}</button>
              }
            </div>
          </div>
          <div class="campo">
            <label>Categoria</label>
            <div class="chips">
              @for (c of categorias; track c.valor) {
                <button type="button" [class.ativo]="f.categoria === c.valor" (click)="f.categoria = c.valor">{{ c.icone }} {{ c.rotulo }}</button>
              }
            </div>
          </div>
          <div class="campo">
            <label for="data">Data</label>
            <input id="data" name="data" type="date" [(ngModel)]="f.data" required>
          </div>
          <button class="btn btn-primario btn-bloco" type="submit" [disabled]="salvando()">{{ salvando() ? 'Salvando…' : 'Salvar' }}</button>
          @if (f.id) {
            <button class="btn btn-perigo btn-bloco" type="button" (click)="excluir(f.id)" [disabled]="salvando()">Excluir gasto</button>
          }
        </form>
      </div>
    }
  `,
  styles: `
    .total { display: flex; align-items: center; justify-content: space-between; }
    .dia { font-weight: 800; margin-bottom: 2px; }
  `,
})
export class GastosPagina {
  private readonly api = inject(Api);
  private readonly avisos = inject(Avisos);
  private readonly sessao = inject(SessaoService);

  protected readonly mes = signal(mesAtual());
  protected readonly dados = signal<GastosMes | null>(null);
  protected readonly form = signal<FormGasto | null>(null);
  protected readonly salvando = signal(false);

  protected readonly categorias = CATEGORIAS;
  protected readonly moeda = moeda;
  protected readonly nomeDia = nomeDia;
  protected readonly icone = iconeCategoria;

  /** Opções de dono: o casal, eu e (se houver) a outra pessoa. */
  protected readonly donos = computed(() => {
    const opcoes: { id: number | null; nome: string }[] = [{ id: null, nome: this.sessao.parceiro() ? 'Nosso' : 'Da casa' }];
    opcoes.push({ id: this.sessao.euId(), nome: 'Meu' });
    const outro = this.sessao.parceiro();
    if (outro) opcoes.push({ id: outro.id, nome: outro.nome.split(' ')[0] });
    return opcoes;
  });

  constructor() {
    effect(() => {
      const mes = this.mes();
      untracked(() => this.carregar(mes));
    });
  }

  carregar(mes: string): void {
    this.api.gastos(mes).subscribe({ next: (d) => this.dados.set(d), error: (e) => this.avisos.erro(e) });
  }

  novo(): void {
    // No mês atual, sugere hoje; em outro mês, o primeiro dia dele.
    const dataSugerida = this.mes() === mesAtual() ? hoje() : `${this.mes()}-01`;
    this.form.set({ id: null, descricao: '', valor: '', data: dataSugerida, categoria: 'MERCADO', donoId: null });
  }

  editar(g: Gasto): void {
    this.form.set({
      id: g.id, descricao: g.descricao, valor: valorParaCampo(g.valor),
      data: g.data, categoria: g.categoria, donoId: g.donoId,
    });
  }

  fechar(): void {
    if (!this.salvando()) this.form.set(null);
  }

  salvar(): void {
    const f = this.form();
    if (!f) return;
    const valor = lerValor(f.valor);
    if (valor === null || valor <= 0) return this.avisos.mostrar('Digite um valor maior que zero.', true);
    if (!f.descricao.trim()) return this.avisos.mostrar('Descreva o gasto.', true);

    const corpo = { data: f.data, descricao: f.descricao.trim(), valor, categoria: f.categoria, donoId: f.donoId };
    this.salvando.set(true);
    const pedido = f.id ? this.api.atualizarGasto(f.id, corpo) : this.api.criarGasto(corpo);
    pedido.subscribe({
      next: () => {
        this.salvando.set(false);
        this.form.set(null);
        this.avisos.mostrar(f.id ? 'Gasto atualizado.' : 'Gasto lançado.');
        // Se o gasto foi lançado em outro mês, mostra esse mês.
        const mesDoGasto = f.data.slice(0, 7);
        if (mesDoGasto !== this.mes()) this.mes.set(mesDoGasto);
        else this.carregar(this.mes());
      },
      error: (e) => {
        this.salvando.set(false);
        this.avisos.erro(e);
      },
    });
  }

  excluir(id: number): void {
    if (!confirm('Excluir este gasto?')) return;
    this.salvando.set(true);
    this.api.excluirGasto(id).subscribe({
      next: () => {
        this.salvando.set(false);
        this.form.set(null);
        this.avisos.mostrar('Gasto excluído.');
        this.carregar(this.mes());
      },
      error: (e) => {
        this.salvando.set(false);
        this.avisos.erro(e);
      },
    });
  }

  rotuloDono(g: Gasto): string {
    if (g.donoId === null) return this.sessao.parceiro() ? 'Nosso' : 'Da casa';
    return g.donoId === this.sessao.euId() ? 'Meu' : (g.donoNome ?? '').split(' ')[0];
  }

  classeDono(donoId: number | null): string {
    if (donoId === null) return 'tag';
    const indice = this.sessao.perfil()?.pessoas.findIndex((p) => p.id === donoId) ?? 0;
    return indice === 1 ? 'tag p2' : 'tag p1';
  }
}
