import { Component, computed, model } from '@angular/core';
import { mesAtual, nomeMes, somarMeses } from '../core/formato';

/** ‹ outubro de 2026 › */
@Component({
  selector: 'app-seletor-mes',
  template: `
    <div class="seletor-mes">
      <button type="button" (click)="mudar(-1)" aria-label="Mês anterior">‹</button>
      <strong>{{ rotulo() }}</strong>
      <button type="button" (click)="mudar(1)" aria-label="Próximo mês">›</button>
    </div>
  `,
})
export class SeletorMes {
  readonly mes = model(mesAtual());
  protected readonly rotulo = computed(() => nomeMes(this.mes()));

  mudar(delta: number): void {
    this.mes.set(somarMeses(this.mes(), delta));
  }
}
