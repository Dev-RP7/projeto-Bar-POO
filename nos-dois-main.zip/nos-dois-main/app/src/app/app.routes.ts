import { Routes } from '@angular/router';
import { precisaLogin, soVisitante } from './core/guards';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'mes' },

  // Entrada (sem login)
  { path: 'entrar', canActivate: [soVisitante], loadComponent: () => import('./paginas/entrada/entrar').then((m) => m.Entrar) },
  { path: 'criar-conta', canActivate: [soVisitante], loadComponent: () => import('./paginas/entrada/criar-conta').then((m) => m.CriarConta) },
  { path: 'verificar', canActivate: [soVisitante], loadComponent: () => import('./paginas/entrada/verificar').then((m) => m.Verificar) },
  { path: 'esqueci-senha', canActivate: [soVisitante], loadComponent: () => import('./paginas/entrada/esqueci-senha').then((m) => m.EsqueciSenha) },

  // Link de convite: abre com ou sem login
  { path: 'convite/:codigo', loadComponent: () => import('./paginas/convite').then((m) => m.ConvitePagina) },

  // App (com login), dentro da casca com a barra de navegação
  {
    path: '',
    canActivate: [precisaLogin],
    loadComponent: () => import('./layout/casca').then((m) => m.Casca),
    children: [
      { path: 'mes', loadComponent: () => import('./paginas/mes').then((m) => m.MesPagina), title: 'Mês · Nós Dois' },
      { path: 'gastos', loadComponent: () => import('./paginas/gastos').then((m) => m.GastosPagina), title: 'Gastos · Nós Dois' },
      { path: 'historico', loadComponent: () => import('./paginas/historico').then((m) => m.HistoricoPagina), title: 'Histórico · Nós Dois' },
      { path: 'juntos', loadComponent: () => import('./paginas/juntos').then((m) => m.JuntosPagina), title: 'Juntos · Nós Dois' },
      { path: 'perfil', loadComponent: () => import('./paginas/perfil').then((m) => m.PerfilPagina), title: 'Perfil · Nós Dois' },
    ],
  },

  { path: '**', redirectTo: 'mes' },
];
