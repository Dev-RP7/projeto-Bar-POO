package br.com.nosdois.repositorio;

import br.com.nosdois.dominio.Deposito;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface DepositoRepository extends JpaRepository<Deposito, Long> {

    /** Depósitos de todas as metas do casal num período (inclusive). */
    @Query("""
            select d from Deposito d
            where d.meta.casal.id = :casalId and d.data between :inicio and :fim
            """)
    List<Deposito> doPeriodo(@Param("casalId") Long casalId, @Param("inicio") LocalDate inicio, @Param("fim") LocalDate fim);

    @Query("select coalesce(sum(d.valor), 0) from Deposito d where d.meta.casal.id = :casalId")
    BigDecimal totalGuardado(@Param("casalId") Long casalId);

    @Query("select d from Deposito d where d.id = :id and d.meta.casal.id = :casalId")
    Optional<Deposito> doCasal(@Param("id") Long id, @Param("casalId") Long casalId);
}
