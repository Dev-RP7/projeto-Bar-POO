package br.com.nosdois.servico;

import br.com.nosdois.dominio.Casal;
import br.com.nosdois.dominio.Renda;
import br.com.nosdois.dominio.Usuario;
import br.com.nosdois.excecao.ApiException;
import br.com.nosdois.repositorio.CasalRepository;
import br.com.nosdois.repositorio.RendaRepository;
import br.com.nosdois.repositorio.UsuarioRepository;
import br.com.nosdois.servico.calculo.Calculadora;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.YearMonth;
import java.util.*;

/** Carrega de uma vez o casal, as pessoas e o histórico de rendas, usados por vários cálculos. */
@Component
public class ContextoCasal {

    private final CasalRepository casalRepository;
    private final UsuarioRepository usuarioRepository;
    private final RendaRepository rendaRepository;

    public ContextoCasal(CasalRepository casalRepository, UsuarioRepository usuarioRepository, RendaRepository rendaRepository) {
        this.casalRepository = casalRepository;
        this.usuarioRepository = usuarioRepository;
        this.rendaRepository = rendaRepository;
    }

    /** Deve ser chamado dentro de uma transação. */
    public Dados carregar(Long casalId) {
        Casal casal = casalRepository.findById(casalId).orElseThrow(() -> ApiException.naoEncontrado("Casal"));
        List<Usuario> pessoas = usuarioRepository.findByCasalIdOrderByIdAsc(casalId);
        Map<Long, NavigableMap<YearMonth, BigDecimal>> rendas = new HashMap<>();
        pessoas.forEach(p -> rendas.put(p.getId(), new TreeMap<>()));
        for (Renda r : rendaRepository.findByCasalId(casalId)) {
            rendas.computeIfAbsent(r.getUsuario().getId(), k -> new TreeMap<>()).put(r.getMes(), r.getValor());
        }
        return new Dados(casal, pessoas, rendas);
    }

    public record Dados(Casal casal, List<Usuario> pessoas, Map<Long, NavigableMap<YearMonth, BigDecimal>> rendas) {

        public BigDecimal renda(Long usuarioId, YearMonth mes) {
            return Calculadora.rendaDoMes(rendas.getOrDefault(usuarioId, new TreeMap<>()), mes);
        }

        public boolean rendaRepetida(Long usuarioId, YearMonth mes) {
            NavigableMap<YearMonth, BigDecimal> mapa = rendas.getOrDefault(usuarioId, new TreeMap<>());
            return !mapa.containsKey(mes) && mapa.floorKey(mes) != null;
        }

        public List<BigDecimal> rendasDoMes(YearMonth mes) {
            return pessoas.stream().map(p -> renda(p.getId(), mes)).toList();
        }

        public BigDecimal totalRendas(YearMonth mes) {
            return Calculadora.soma(rendasDoMes(mes));
        }

        /** Primeiro mês com renda registrada por alguém, se houver. */
        public Optional<YearMonth> primeiroMesComRenda() {
            return rendas.values().stream().filter(m -> !m.isEmpty()).map(NavigableMap::firstKey).min(Comparator.naturalOrder());
        }

        public Optional<Usuario> pessoa(Long id) {
            return pessoas.stream().filter(p -> p.getId().equals(id)).findFirst();
        }
    }
}
