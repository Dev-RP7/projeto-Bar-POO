package br.com.nosdois.repositorio;

import br.com.nosdois.dominio.Casal;
import br.com.nosdois.dominio.Gasto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface GastoRepository extends JpaRepository<Gasto, Long> {

    /** Gastos de um período (inclusive), mais recentes primeiro. */
    @Query("""
            select g from Gasto g
            left join fetch g.dono
            where g.casal.id = :casalId and g.data between :inicio and :fim
            order by g.data desc, g.id desc
            """)
    List<Gasto> doPeriodo(@Param("casalId") Long casalId, @Param("inicio") LocalDate inicio, @Param("fim") LocalDate fim);

    Optional<Gasto> findByIdAndCasalId(Long id, Long casalId);

    List<Gasto> findByCasalId(Long casalId);

    /** Data do gasto mais antigo do casal (início do histórico). */
    @Query("select min(g.data) from Gasto g where g.casal.id = :casalId")
    Optional<LocalDate> primeiraData(@Param("casalId") Long casalId);

    /** Move todos os gastos de um casal para outro (quando o convite é aceito). */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("update Gasto g set g.casal = :destino where g.casal.id = :origem")
    void moverTodos(@Param("origem") Long origem, @Param("destino") Casal destino);

    /** Move os gastos individuais de uma pessoa (quando ela sai do casal). */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("update Gasto g set g.casal = :destino where g.dono.id = :usuarioId")
    void moverIndividuais(@Param("usuarioId") Long usuarioId, @Param("destino") Casal destino);
}
