package br.com.nosdois.servico;

import br.com.nosdois.dominio.Deposito;
import br.com.nosdois.dominio.Meta;
import br.com.nosdois.dto.FinancasDtos.*;
import br.com.nosdois.excecao.ApiException;
import br.com.nosdois.repositorio.CasalRepository;
import br.com.nosdois.repositorio.DepositoRepository;
import br.com.nosdois.repositorio.MetaRepository;
import br.com.nosdois.repositorio.UsuarioRepository;
import br.com.nosdois.seguranca.UsuarioLogado;
import br.com.nosdois.servico.calculo.Calculadora;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.Clock;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/** Tela "Juntos": metas, depósitos, total guardado e ideias para a sobra. */
@Slf4j
@Service
public class MetaService {

    private final MetaRepository metaRepository;
    private final DepositoRepository depositoRepository;
    private final CasalRepository casalRepository;
    private final UsuarioRepository usuarioRepository;
    private final ContextoCasal contextoCasal;
    private final ResumoService resumoService;
    private final Clock clock;

    public MetaService(MetaRepository metaRepository, DepositoRepository depositoRepository,
                       CasalRepository casalRepository, UsuarioRepository usuarioRepository,
                       ContextoCasal contextoCasal, ResumoService resumoService, Clock clock) {
        this.metaRepository = metaRepository;
        this.depositoRepository = depositoRepository;
        this.casalRepository = casalRepository;
        this.usuarioRepository = usuarioRepository;
        this.contextoCasal = contextoCasal;
        this.resumoService = resumoService;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public JuntosResponse juntos(UsuarioLogado eu) {
        YearMonth hoje = YearMonth.now(clock);
        ContextoCasal.Dados ctx = contextoCasal.carregar(eu.casalId());
        List<MetaResponse> metas = metaRepository.findByCasalIdOrderByIdAsc(eu.casalId()).stream()
                .map(m -> paraResponse(m, ctx, hoje)).toList();
        BigDecimal totalGuardado = Calculadora.dinheiro(depositoRepository.totalGuardado(eu.casalId()));
        ResumoMesResponse resumo = resumoService.resumo(eu.casalId(), eu.usuarioId(), hoje);
        return new JuntosResponse(totalGuardado, resumo.disponivelParaGuardar(), metas, ideias(resumo, metas, totalGuardado));
    }

    @Transactional
    public MetaResponse criar(UsuarioLogado eu, MetaRequest req) {
        Meta meta = new Meta();
        meta.setCasal(casalRepository.getReferenceById(eu.casalId()));
        preencher(meta, req);
        metaRepository.save(meta);
        log.info("Meta {} criada no casal {}", meta.getId(), eu.casalId());
        return paraResponse(meta, contextoCasal.carregar(eu.casalId()), YearMonth.now(clock));
    }

    @Transactional
    public MetaResponse atualizar(UsuarioLogado eu, Long id, MetaRequest req) {
        Meta meta = buscar(eu, id);
        preencher(meta, req);
        return paraResponse(meta, contextoCasal.carregar(eu.casalId()), YearMonth.now(clock));
    }

    /** Excluir a meta apaga os depósitos; o valor volta para a sobra. */
    @Transactional
    public void excluir(UsuarioLogado eu, Long id) {
        metaRepository.delete(buscar(eu, id));
        log.info("Meta {} excluída do casal {}", id, eu.casalId());
    }

    @Transactional
    public MetaResponse depositar(UsuarioLogado eu, Long metaId, DepositoRequest req) {
        Meta meta = buscar(eu, metaId);
        Deposito deposito = new Deposito();
        deposito.setMeta(meta);
        deposito.setValor(Calculadora.dinheiro(req.valor()));
        deposito.setData(req.data() != null ? req.data() : LocalDate.now(clock));
        deposito.setCriadoPor(usuarioRepository.getReferenceById(eu.usuarioId()));
        meta.getDepositos().add(0, deposito);
        depositoRepository.save(deposito);
        return paraResponse(meta, contextoCasal.carregar(eu.casalId()), YearMonth.now(clock));
    }

    @Transactional
    public MetaResponse excluirDeposito(UsuarioLogado eu, Long metaId, Long depositoId) {
        Meta meta = buscar(eu, metaId);
        Deposito deposito = meta.getDepositos().stream().filter(d -> d.getId().equals(depositoId)).findFirst()
                .orElseThrow(() -> ApiException.naoEncontrado("Depósito"));
        meta.getDepositos().remove(deposito);
        return paraResponse(meta, contextoCasal.carregar(eu.casalId()), YearMonth.now(clock));
    }

    private void preencher(Meta meta, MetaRequest req) {
        meta.setNome(req.nome().trim());
        meta.setValorAlvo(req.valorAlvo() == null ? null : Calculadora.dinheiro(req.valorAlvo()));
        meta.setPrazo(req.prazo());
    }

    private Meta buscar(UsuarioLogado eu, Long id) {
        return metaRepository.findByIdAndCasalId(id, eu.casalId()).orElseThrow(() -> ApiException.naoEncontrado("Meta"));
    }

    private MetaResponse paraResponse(Meta m, ContextoCasal.Dados ctx, YearMonth hoje) {
        BigDecimal guardado = Calculadora.soma(m.getDepositos().stream().map(Deposito::getValor).toList());
        boolean alcancada = m.getValorAlvo() != null && guardado.compareTo(m.getValorAlvo()) >= 0;
        boolean vencido = m.getPrazo() != null && m.getPrazo().isBefore(hoje) && !alcancada;
        Optional<BigDecimal> parcela = Calculadora.parcelaMensal(m.getValorAlvo(), guardado, m.getPrazo(), hoje);

        List<ParteResponse> partes = new ArrayList<>();
        parcela.ifPresent(valor -> {
            List<BigDecimal> divisao = Calculadora.dividir(valor, ctx.rendasDoMes(hoje), ctx.casal().getRegraDivisao());
            for (int i = 0; i < ctx.pessoas().size(); i++) {
                partes.add(new ParteResponse(ctx.pessoas().get(i).getId(), ctx.pessoas().get(i).getNome(), divisao.get(i)));
            }
        });

        List<DepositoResponse> depositos = m.getDepositos().stream()
                .map(d -> new DepositoResponse(d.getId(), d.getData(), d.getValor(), d.getCriadoPor().getNome()))
                .toList();
        return new MetaResponse(m.getId(), m.getNome(), m.getValorAlvo(), m.getPrazo(), guardado,
                Calculadora.progresso(m.getValorAlvo(), guardado), alcancada, vencido,
                parcela.orElse(null), partes, depositos);
    }

    /** Sugestões simples para a sobra do mês. Referências gerais, não aconselhamento financeiro. */
    private List<String> ideias(ResumoMesResponse resumo, List<MetaResponse> metas, BigDecimal totalGuardado) {
        NumberFormat real = NumberFormat.getCurrencyInstance(Locale.of("pt", "BR"));
        List<String> ideias = new ArrayList<>();
        BigDecimal disponivel = resumo.disponivelParaGuardar();
        BigDecimal parcelas = Calculadora.soma(metas.stream().map(MetaResponse::parcelaMensal).filter(java.util.Objects::nonNull).toList());

        if (disponivel.signum() <= 0) {
            ideias.add("Este mês ainda não sobrou dinheiro para guardar. Veja em Gastos quais categorias pesaram mais.");
        } else if (parcelas.signum() > 0 && disponivel.compareTo(parcelas) >= 0) {
            ideias.add("A sobra cobre as parcelas de todas as metas (" + real.format(parcelas) + ") e ainda fica "
                    + real.format(disponivel.subtract(parcelas)) + " livre.");
        } else if (parcelas.signum() > 0) {
            ideias.add("As parcelas das metas somam " + real.format(parcelas) + " e sobraram " + real.format(disponivel)
                    + ". Vale priorizar a meta com prazo mais próximo.");
        } else {
            ideias.add("Sobraram " + real.format(disponivel) + " este mês. Que tal criar uma meta para esse dinheiro?");
        }

        BigDecimal minimo = resumo.reserva().minimo();
        if (minimo.signum() > 0 && totalGuardado.compareTo(minimo) < 0) {
            ideias.add("Reserva de emergência: uma referência comum é ter de 3 a 6 meses de gastos guardados ("
                    + real.format(minimo) + " a " + real.format(resumo.reserva().maximo())
                    + "). É uma referência geral, não um aconselhamento financeiro.");
        }
        metas.stream().filter(MetaResponse::prazoVencido).findFirst().ifPresent(m ->
                ideias.add("O prazo da meta \"" + m.nome() + "\" passou. Que tal definir um prazo novo?"));
        return ideias;
    }
}
