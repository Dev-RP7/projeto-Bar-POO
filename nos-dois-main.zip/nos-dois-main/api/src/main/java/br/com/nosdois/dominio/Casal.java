package br.com.nosdois.dominio;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Espaço compartilhado de finanças. Toda conta nasce com o próprio casal (de uma pessoa);
 * quando o convite é aceito, a segunda pessoa entra nele.
 */
@Entity
@Table(name = "casal")
@Getter
@Setter
@NoArgsConstructor
public class Casal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "codigo_convite", nullable = false, unique = true, length = 6)
    private String codigoConvite;

    @Enumerated(EnumType.STRING)
    @Column(name = "regra_divisao", nullable = false)
    private RegraDivisao regraDivisao = RegraDivisao.PROPORCIONAL;

    @Column(name = "criado_em", nullable = false)
    private LocalDateTime criadoEm = LocalDateTime.now();

    public Casal(String codigoConvite) {
        this.codigoConvite = codigoConvite;
    }
}
