package br.com.nosdois.seguranca;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;

/** Gera e valida o token de acesso (JWT de curta duração). */
@Service
public class JwtService {

    private static final String EMISSOR = "nos-dois";

    private final Algorithm algoritmo;
    private final Duration validade;

    public JwtService(@Value("${app.jwt.segredo}") String segredo,
                      @Value("${app.jwt.validade-acesso:15m}") Duration validade) {
        if (segredo == null || segredo.length() < 32) {
            throw new IllegalStateException("app.jwt.segredo precisa ter pelo menos 32 caracteres");
        }
        this.algoritmo = Algorithm.HMAC256(segredo);
        this.validade = validade;
    }

    public String gerar(Long usuarioId) {
        return JWT.create()
                .withIssuer(EMISSOR)
                .withSubject(usuarioId.toString())
                .withExpiresAt(Instant.now().plus(validade))
                .sign(algoritmo);
    }

    /** Devolve o id do usuário, ou null se o token for inválido ou estiver expirado. */
    public Long validar(String token) {
        try {
            String sub = JWT.require(algoritmo).withIssuer(EMISSOR).build().verify(token).getSubject();
            return Long.valueOf(sub);
        } catch (JWTVerificationException | NumberFormatException e) {
            return null;
        }
    }

    public long validadeEmSegundos() {
        return validade.toSeconds();
    }
}
