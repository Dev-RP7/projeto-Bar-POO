package br.com.nosdois.servico;

import br.com.nosdois.dominio.Renda;
import br.com.nosdois.repositorio.CasalRepository;
import br.com.nosdois.repositorio.RendaRepository;
import br.com.nosdois.repositorio.UsuarioRepository;
import br.com.nosdois.seguranca.UsuarioLogado;
import br.com.nosdois.servico.calculo.Calculadora;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.YearMonth;

/** Cada pessoa edita só a própria renda: o usuário vem do token, nunca do corpo da requisição. */
@Service
public class RendaService {

    private final RendaRepository rendaRepository;
    private final UsuarioRepository usuarioRepository;
    private final CasalRepository casalRepository;

    public RendaService(RendaRepository rendaRepository, UsuarioRepository usuarioRepository, CasalRepository casalRepository) {
        this.rendaRepository = rendaRepository;
        this.usuarioRepository = usuarioRepository;
        this.casalRepository = casalRepository;
    }

    /** Define a renda do mês. Os meses seguintes sem registro passam a repetir este valor. */
    @Transactional
    public void definir(UsuarioLogado eu, YearMonth mes, BigDecimal valor) {
        Renda renda = rendaRepository.findByUsuarioIdAndMes(eu.usuarioId(), mes).orElseGet(() -> {
            Renda nova = new Renda();
            nova.setUsuario(usuarioRepository.getReferenceById(eu.usuarioId()));
            nova.setCasal(casalRepository.getReferenceById(eu.casalId()));
            nova.setMes(mes);
            return nova;
        });
        renda.setValor(Calculadora.dinheiro(valor));
        rendaRepository.save(renda);
    }
}
