package br.com.nosdois.servico;

import br.com.nosdois.dominio.CodigoVerificacao;
import br.com.nosdois.dominio.TipoCodigo;
import br.com.nosdois.dominio.Usuario;
import br.com.nosdois.excecao.ApiException;
import br.com.nosdois.repositorio.CodigoVerificacaoRepository;
import br.com.nosdois.servico.email.EmailService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.Duration;
import java.time.LocalDateTime;

/**
 * Códigos de 6 dígitos por e-mail: validade de 15 minutos, 5 tentativas por código,
 * 1 envio por minuto e 5 envios por hora.
 */
@Service
public class CodigoService {

    static final Duration VALIDADE = Duration.ofMinutes(15);
    static final int MAX_TENTATIVAS = 5;
    static final Duration INTERVALO_REENVIO = Duration.ofSeconds(60);
    static final int MAX_ENVIOS_POR_HORA = 5;

    private static final SecureRandom RANDOM = new SecureRandom();

    private final CodigoVerificacaoRepository repositorio;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;

    public CodigoService(CodigoVerificacaoRepository repositorio, PasswordEncoder passwordEncoder, EmailService emailService) {
        this.repositorio = repositorio;
        this.passwordEncoder = passwordEncoder;
        this.emailService = emailService;
    }

    /**
     * Gera um código novo (invalidando os anteriores) e envia por e-mail.
     * Os limites são conferidos antes de gravar qualquer coisa; noRollbackFor evita que um
     * "aguarde um minuto" desfaça a transação de quem chamou.
     */
    @Transactional(noRollbackFor = ApiException.class)
    public void enviar(Usuario usuario, TipoCodigo tipo) {
        LocalDateTime agora = LocalDateTime.now();
        repositorio.findFirstByUsuarioIdAndTipoOrderByIdDesc(usuario.getId(), tipo)
                .filter(ultimo -> ultimo.getCriadoEm().isAfter(agora.minus(INTERVALO_REENVIO)))
                .ifPresent(ultimo -> {
                    throw ApiException.muitasTentativas("Aguarde um minuto para pedir outro código.");
                });
        if (repositorio.countByUsuarioIdAndTipoAndCriadoEmAfter(usuario.getId(), tipo, agora.minusHours(1)) >= MAX_ENVIOS_POR_HORA) {
            throw ApiException.muitasTentativas("Muitos códigos pedidos. Tente de novo em uma hora.");
        }

        repositorio.invalidarAbertos(usuario.getId(), tipo);

        String codigo = String.format("%06d", RANDOM.nextInt(1_000_000));
        CodigoVerificacao registro = new CodigoVerificacao();
        registro.setUsuario(usuario);
        registro.setTipo(tipo);
        registro.setCodigoHash(passwordEncoder.encode(codigo));
        registro.setExpiraEm(agora.plus(VALIDADE));
        repositorio.save(registro);

        emailService.enviar(usuario.getEmail(), assunto(tipo), texto(usuario, tipo, codigo));
    }

    /**
     * Confere o código. Uma tentativa errada é gravada mesmo com a exceção,
     * por isso não há rollback para ApiException.
     */
    @Transactional(noRollbackFor = ApiException.class)
    public void validar(Usuario usuario, TipoCodigo tipo, String codigo) {
        CodigoVerificacao registro = repositorio
                .findFirstByUsuarioIdAndTipoAndUsadoFalseOrderByIdDesc(usuario.getId(), tipo)
                .orElseThrow(() -> ApiException.regra("CODIGO_EXPIRADO", "Código expirado. Peça um novo."));

        if (registro.getExpiraEm().isBefore(LocalDateTime.now())) {
            throw ApiException.regra("CODIGO_EXPIRADO", "Código expirado. Peça um novo.");
        }
        if (registro.getTentativas() >= MAX_TENTATIVAS) {
            throw ApiException.muitasTentativas("Muitas tentativas erradas. Peça um novo código.");
        }
        if (codigo == null || !passwordEncoder.matches(codigo.trim(), registro.getCodigoHash())) {
            registro.setTentativas(registro.getTentativas() + 1);
            int restantes = MAX_TENTATIVAS - registro.getTentativas();
            throw ApiException.regra("CODIGO_INVALIDO", restantes > 0
                    ? "Código incorreto. Restam " + restantes + " tentativa(s)."
                    : "Código incorreto. Peça um novo código.");
        }
        registro.setUsado(true);
    }

    private String assunto(TipoCodigo tipo) {
        return tipo == TipoCodigo.VERIFICAR_EMAIL ? "Seu código do Nós Dois" : "Recuperar senha do Nós Dois";
    }

    private String texto(Usuario usuario, TipoCodigo tipo, String codigo) {
        String acao = tipo == TipoCodigo.VERIFICAR_EMAIL ? "confirmar seu e-mail" : "criar uma nova senha";
        return """
                Olá, %s!

                Use o código abaixo para %s no Nós Dois:

                %s

                Ele vale por 15 minutos. Se não foi você, ignore este e-mail.
                """.formatted(usuario.getNome(), acao, codigo);
    }
}
