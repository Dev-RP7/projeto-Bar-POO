package br.com.nosdois.servico.email;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

/**
 * Modo de desenvolvimento: em vez de enviar, escreve o e-mail no log.
 * Ativo quando app.email.modo=log (o padrão).
 */
@Slf4j
@Service
@ConditionalOnProperty(name = "app.email.modo", havingValue = "log", matchIfMissing = true)
public class LogEmailService implements EmailService {

    @Override
    public void enviar(String para, String assunto, String texto) {
        log.warn("[E-MAIL SIMULADO] Para: {} | Assunto: {}\n{}", para, assunto, texto);
    }
}
