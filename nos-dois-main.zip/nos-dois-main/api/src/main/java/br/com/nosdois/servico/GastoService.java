package br.com.nosdois.servico;

import br.com.nosdois.dominio.Gasto;
import br.com.nosdois.dominio.Usuario;
import br.com.nosdois.dto.FinancasDtos.*;
import br.com.nosdois.excecao.ApiException;
import br.com.nosdois.repositorio.CasalRepository;
import br.com.nosdois.repositorio.GastoRepository;
import br.com.nosdois.repositorio.UsuarioRepository;
import br.com.nosdois.seguranca.UsuarioLogado;
import br.com.nosdois.servico.calculo.Calculadora;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Gastos do casal. Qualquer um dos dois pode criar, editar e apagar. */
@Slf4j
@Service
public class GastoService {

    private final GastoRepository gastoRepository;
    private final UsuarioRepository usuarioRepository;
    private final CasalRepository casalRepository;

    public GastoService(GastoRepository gastoRepository, UsuarioRepository usuarioRepository, CasalRepository casalRepository) {
        this.gastoRepository = gastoRepository;
        this.usuarioRepository = usuarioRepository;
        this.casalRepository = casalRepository;
    }

    /** Gastos do mês agrupados por dia, do mais recente para o mais antigo. */
    @Transactional(readOnly = true)
    public GastosMesResponse doMes(UsuarioLogado eu, YearMonth mes) {
        List<Gasto> gastos = gastoRepository.doPeriodo(eu.casalId(), mes.atDay(1), mes.atEndOfMonth());
        Map<LocalDate, List<GastoResponse>> porDia = new LinkedHashMap<>();
        for (Gasto g : gastos) {
            porDia.computeIfAbsent(g.getData(), d -> new java.util.ArrayList<>()).add(paraResponse(g));
        }
        List<DiaGastos> dias = porDia.entrySet().stream()
                .map(e -> new DiaGastos(e.getKey(), Calculadora.soma(e.getValue().stream().map(GastoResponse::valor).toList()), e.getValue()))
                .toList();
        return new GastosMesResponse(mes, Calculadora.soma(gastos.stream().map(Gasto::getValor).toList()), dias);
    }

    @Transactional
    public GastoResponse criar(UsuarioLogado eu, GastoRequest req) {
        Gasto gasto = new Gasto();
        gasto.setCasal(casalRepository.getReferenceById(eu.casalId()));
        gasto.setCriadoPor(usuarioRepository.getReferenceById(eu.usuarioId()));
        preencher(gasto, req, eu);
        gastoRepository.save(gasto);
        log.info("Gasto {} criado no casal {}", gasto.getId(), eu.casalId());
        return paraResponse(gasto);
    }

    @Transactional
    public GastoResponse atualizar(UsuarioLogado eu, Long id, GastoRequest req) {
        Gasto gasto = buscar(eu, id);
        preencher(gasto, req, eu);
        return paraResponse(gasto);
    }

    @Transactional
    public void excluir(UsuarioLogado eu, Long id) {
        gastoRepository.delete(buscar(eu, id));
        log.info("Gasto {} excluído do casal {}", id, eu.casalId());
    }

    private void preencher(Gasto gasto, GastoRequest req, UsuarioLogado eu) {
        gasto.setData(req.data());
        gasto.setDescricao(req.descricao().trim());
        gasto.setValor(Calculadora.dinheiro(req.valor()));
        gasto.setCategoria(req.categoria());
        gasto.setDono(req.donoId() == null ? null : pessoaDoCasal(eu, req.donoId()));
    }

    /** O dono de um gasto individual precisa ser uma das pessoas do casal. */
    private Usuario pessoaDoCasal(UsuarioLogado eu, Long usuarioId) {
        return usuarioRepository.findById(usuarioId)
                .filter(u -> u.getCasal().getId().equals(eu.casalId()))
                .orElseThrow(() -> ApiException.regra("DONO_INVALIDO", "Escolha você, a outra pessoa ou o casal."));
    }

    private Gasto buscar(UsuarioLogado eu, Long id) {
        return gastoRepository.findByIdAndCasalId(id, eu.casalId()).orElseThrow(() -> ApiException.naoEncontrado("Gasto"));
    }

    static GastoResponse paraResponse(Gasto g) {
        return new GastoResponse(
                g.getId(), g.getData(), g.getDescricao(), g.getValor(),
                g.getCategoria(), g.getCategoria().getRotulo(),
                g.isDoCasal() ? null : g.getDono().getId(),
                g.isDoCasal() ? null : g.getDono().getNome(),
                g.getCriadoPor().getId(), g.getCriadoPor().getNome());
    }
}
