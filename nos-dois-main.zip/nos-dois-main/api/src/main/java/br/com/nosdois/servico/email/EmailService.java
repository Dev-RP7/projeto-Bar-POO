package br.com.nosdois.servico.email;

/** Envia e-mails transacionais (códigos de verificação e de recuperação de senha). */
public interface EmailService {

    void enviar(String para, String assunto, String texto);
}
