package br.com.nosdois.web;

import br.com.nosdois.dto.AuthDtos.*;
import br.com.nosdois.servico.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/** Rotas públicas de conta e sessão. */
@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/cadastro")
    public ResponseEntity<MensagemResponse> cadastrar(@RequestBody @Valid CadastroRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(authService.cadastrar(req));
    }

    @PostMapping("/verificar")
    public SessaoResponse verificar(@RequestBody @Valid VerificarRequest req) {
        return authService.verificarEmail(req);
    }

    @PostMapping("/reenviar-codigo")
    public MensagemResponse reenviarCodigo(@RequestBody @Valid EmailRequest req) {
        return authService.reenviarCodigo(req);
    }

    @PostMapping("/login")
    public SessaoResponse login(@RequestBody @Valid LoginRequest req) {
        return authService.login(req);
    }

    @PostMapping("/renovar")
    public SessaoResponse renovar(@RequestBody @Valid RenovarRequest req) {
        return authService.renovar(req);
    }

    @PostMapping("/sair")
    public ResponseEntity<Void> sair(@RequestBody @Valid RenovarRequest req) {
        authService.sair(req);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/esqueci-senha")
    public MensagemResponse esqueciSenha(@RequestBody @Valid EmailRequest req) {
        return authService.esqueciSenha(req);
    }

    @PostMapping("/redefinir-senha")
    public SessaoResponse redefinirSenha(@RequestBody @Valid RedefinirSenhaRequest req) {
        return authService.redefinirSenha(req);
    }
}
