package br.com.nosdois.dominio;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import java.time.YearMonth;

/** Grava YearMonth como texto "AAAA-MM" no banco. */
@Converter(autoApply = true)
public class MesConverter implements AttributeConverter<YearMonth, String> {

    @Override
    public String convertToDatabaseColumn(YearMonth mes) {
        return mes == null ? null : mes.toString();
    }

    @Override
    public YearMonth convertToEntityAttribute(String valor) {
        return valor == null ? null : YearMonth.parse(valor);
    }
}
