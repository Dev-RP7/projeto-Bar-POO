package br.com.nosdois.servico;

import br.com.nosdois.dominio.Deposito;
import br.com.nosdois.dominio.Gasto;
import br.com.nosdois.dto.FinancasDtos.HistoricoResponse;
import br.com.nosdois.dto.FinancasDtos.LinhaHistorico;
import br.com.nosdois.repositorio.DepositoRepository;
import br.com.nosdois.repositorio.GastoRepository;
import br.com.nosdois.servico.calculo.Calculadora;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.Year;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.*;
import java.util.function.Function;

/** Histórico por dia (de um mês), por mês (de um ano) e por ano: entrou, saiu, sobrou e guardado. */
@Service
public class HistoricoService {

    private static final Locale PT_BR = Locale.of("pt", "BR");

    private final ContextoCasal contextoCasal;
    private final GastoRepository gastoRepository;
    private final DepositoRepository depositoRepository;
    private final Clock clock;

    public HistoricoService(ContextoCasal contextoCasal, GastoRepository gastoRepository,
                            DepositoRepository depositoRepository, Clock clock) {
        this.contextoCasal = contextoCasal;
        this.gastoRepository = gastoRepository;
        this.depositoRepository = depositoRepository;
        this.clock = clock;
    }

    /** Dias do mês com algum gasto ou depósito. A renda é mensal, por isso "entrou" fica zerado nos dias. */
    @Transactional(readOnly = true)
    public HistoricoResponse porDia(Long casalId, YearMonth mes) {
        Map<LocalDate, BigDecimal> saiu = somar(gastoRepository.doPeriodo(casalId, mes.atDay(1), mes.atEndOfMonth()),
                Gasto::getData, Gasto::getValor);
        Map<LocalDate, BigDecimal> guardado = somar(depositoRepository.doPeriodo(casalId, mes.atDay(1), mes.atEndOfMonth()),
                Deposito::getData, Deposito::getValor);

        TreeSet<LocalDate> dias = new TreeSet<>(Comparator.reverseOrder());
        dias.addAll(saiu.keySet());
        dias.addAll(guardado.keySet());

        List<LinhaHistorico> linhas = dias.stream().map(d -> linha(
                d.toString(), d.getDayOfMonth() + " " + d.getMonth().getDisplayName(TextStyle.SHORT, PT_BR),
                Calculadora.ZERO, saiu.getOrDefault(d, BigDecimal.ZERO), guardado.getOrDefault(d, BigDecimal.ZERO), false)).toList();
        return new HistoricoResponse("dia", mes.toString(), linhas, total(mes.toString(), linhas));
    }

    /** Os 12 meses de um ano. Meses futuros aparecem marcados e zerados. */
    @Transactional(readOnly = true)
    public HistoricoResponse porMes(Long casalId, int ano) {
        ContextoCasal.Dados ctx = contextoCasal.carregar(casalId);
        YearMonth atual = YearMonth.now(clock);
        Map<YearMonth, BigDecimal> saiu = somar(gastoRepository.doPeriodo(casalId, LocalDate.of(ano, 1, 1), LocalDate.of(ano, 12, 31)),
                g -> YearMonth.from(g.getData()), Gasto::getValor);
        Map<YearMonth, BigDecimal> guardado = somar(depositoRepository.doPeriodo(casalId, LocalDate.of(ano, 1, 1), LocalDate.of(ano, 12, 31)),
                d -> YearMonth.from(d.getData()), Deposito::getValor);

        List<LinhaHistorico> linhas = new ArrayList<>();
        for (int m = 1; m <= 12; m++) {
            YearMonth mes = YearMonth.of(ano, m);
            String rotulo = capitalizar(mes.getMonth().getDisplayName(TextStyle.FULL, PT_BR));
            boolean futuro = mes.isAfter(atual);
            linhas.add(futuro
                    ? linha(mes.toString(), rotulo, Calculadora.ZERO, Calculadora.ZERO, Calculadora.ZERO, true)
                    : linha(mes.toString(), rotulo, ctx.totalRendas(mes),
                    saiu.getOrDefault(mes, BigDecimal.ZERO), guardado.getOrDefault(mes, BigDecimal.ZERO), false));
        }
        return new HistoricoResponse("mes", String.valueOf(ano), linhas, total(String.valueOf(ano), linhas));
    }

    /** Um resumo por ano, do primeiro ano com dados até o atual. */
    @Transactional(readOnly = true)
    public HistoricoResponse porAno(Long casalId) {
        ContextoCasal.Dados ctx = contextoCasal.carregar(casalId);
        int anoAtual = Year.now(clock).getValue();
        int primeiroAno = anoAtual;
        Optional<LocalDate> primeiroGasto = gastoRepository.primeiraData(casalId);
        if (primeiroGasto.isPresent()) {
            primeiroAno = Math.min(primeiroAno, primeiroGasto.get().getYear());
        }
        Optional<YearMonth> primeiraRenda = ctx.primeiroMesComRenda();
        if (primeiraRenda.isPresent()) {
            primeiroAno = Math.min(primeiroAno, primeiraRenda.get().getYear());
        }

        List<LinhaHistorico> linhas = new ArrayList<>();
        for (int ano = anoAtual; ano >= primeiroAno; ano--) {
            LinhaHistorico totalAno = porMes(casalId, ano).total();
            linhas.add(linha(String.valueOf(ano), String.valueOf(ano),
                    totalAno.entrou(), totalAno.saiu(), totalAno.guardado(), false));
        }
        return new HistoricoResponse("ano", "todos", linhas, total("todos", linhas));
    }

    private static LinhaHistorico linha(String periodo, String rotulo, BigDecimal entrou, BigDecimal saiu,
                                        BigDecimal guardado, boolean futuro) {
        BigDecimal e = Calculadora.dinheiro(entrou);
        BigDecimal s = Calculadora.dinheiro(saiu);
        return new LinhaHistorico(periodo, rotulo, e, s, e.subtract(s), Calculadora.dinheiro(guardado), futuro);
    }

    private static LinhaHistorico total(String periodo, List<LinhaHistorico> linhas) {
        List<LinhaHistorico> reais = linhas.stream().filter(l -> !l.futuro()).toList();
        return linha(periodo, "Total",
                Calculadora.soma(reais.stream().map(LinhaHistorico::entrou).toList()),
                Calculadora.soma(reais.stream().map(LinhaHistorico::saiu).toList()),
                Calculadora.soma(reais.stream().map(LinhaHistorico::guardado).toList()), false);
    }

    private static <T, K> Map<K, BigDecimal> somar(List<T> itens, Function<T, K> chave, Function<T, BigDecimal> valor) {
        Map<K, BigDecimal> mapa = new HashMap<>();
        for (T item : itens) {
            mapa.merge(chave.apply(item), valor.apply(item), BigDecimal::add);
        }
        return mapa;
    }

    private static String capitalizar(String texto) {
        return texto.isEmpty() ? texto : Character.toUpperCase(texto.charAt(0)) + texto.substring(1);
    }
}
