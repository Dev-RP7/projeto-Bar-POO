package br.com.nosdois.dominio;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

/** Meta do casal. Valor e prazo são opcionais. */
@Entity
@Table(name = "meta")
@Getter
@Setter
@NoArgsConstructor
public class Meta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "casal_id")
    private Casal casal;

    @Column(nullable = false, length = 80)
    private String nome;

    @Column(name = "valor_alvo", precision = 12, scale = 2)
    private BigDecimal valorAlvo;

    @Column(length = 7)
    private YearMonth prazo;

    @Column(name = "criado_em", nullable = false)
    private LocalDateTime criadoEm = LocalDateTime.now();

    @OneToMany(mappedBy = "meta", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("data DESC, id DESC")
    private List<Deposito> depositos = new ArrayList<>();
}
