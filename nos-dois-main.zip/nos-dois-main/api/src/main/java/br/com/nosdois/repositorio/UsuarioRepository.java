package br.com.nosdois.repositorio;

import br.com.nosdois.dominio.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    Optional<Usuario> findByEmailIgnoreCase(String email);

    boolean existsByEmailIgnoreCase(String email);

    /** Membros de um casal, do mais antigo para o mais novo. */
    List<Usuario> findByCasalIdOrderByIdAsc(Long casalId);

    long countByCasalId(Long casalId);
}
