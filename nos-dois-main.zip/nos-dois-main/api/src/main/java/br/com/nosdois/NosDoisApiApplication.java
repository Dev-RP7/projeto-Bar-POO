package br.com.nosdois;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NosDoisApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NosDoisApiApplication.class, args);
	}

}
