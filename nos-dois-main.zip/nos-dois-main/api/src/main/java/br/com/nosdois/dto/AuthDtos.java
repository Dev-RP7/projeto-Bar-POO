package br.com.nosdois.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** Dados de entrada e saída da autenticação. */
public final class AuthDtos {

    private AuthDtos() {
    }

    public record CadastroRequest(
            @NotBlank(message = "Informe seu nome") @Size(max = 80, message = "Nome muito longo") String nome,
            @NotBlank(message = "Informe seu e-mail") @Email(message = "E-mail inválido") @Size(max = 120) String email,
            @NotBlank(message = "Crie uma senha") @Size(min = 8, max = 72, message = "A senha deve ter entre 8 e 72 caracteres") String senha
    ) {
    }

    public record LoginRequest(
            @NotBlank(message = "Informe seu e-mail") @Email(message = "E-mail inválido") String email,
            @NotBlank(message = "Informe sua senha") String senha
    ) {
    }

    public record VerificarRequest(
            @NotBlank(message = "Informe seu e-mail") @Email(message = "E-mail inválido") String email,
            @NotBlank(message = "Informe o código") @Pattern(regexp = "\\d{6}", message = "O código tem 6 números") String codigo
    ) {
    }

    public record EmailRequest(
            @NotBlank(message = "Informe seu e-mail") @Email(message = "E-mail inválido") String email
    ) {
    }

    public record RedefinirSenhaRequest(
            @NotBlank(message = "Informe seu e-mail") @Email(message = "E-mail inválido") String email,
            @NotBlank(message = "Informe o código") @Pattern(regexp = "\\d{6}", message = "O código tem 6 números") String codigo,
            @NotBlank(message = "Crie uma senha") @Size(min = 8, max = 72, message = "A senha deve ter entre 8 e 72 caracteres") String novaSenha
    ) {
    }

    public record RenovarRequest(@NotBlank String refreshToken) {
    }

    /** Resposta de login, verificação e renovação. */
    public record SessaoResponse(String accessToken, String refreshToken, long expiraEmSegundos, PerfilDtos.PerfilResponse perfil) {
    }

    public record MensagemResponse(String mensagem) {
    }
}
