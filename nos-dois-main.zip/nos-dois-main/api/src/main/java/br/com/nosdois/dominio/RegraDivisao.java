package br.com.nosdois.dominio;

/** Como as contas do casal são divididas entre os dois. */
public enum RegraDivisao {
    /** Cada um paga proporcionalmente à própria renda. */
    PROPORCIONAL,
    /** Metade para cada um. */
    IGUAL
}
