package br.com.nosdois.dominio;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.YearMonth;

/** Renda de uma pessoa num mês. */
@Entity
@Table(name = "renda")
@Getter
@Setter
@NoArgsConstructor
public class Renda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "casal_id")
    private Casal casal;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    @Column(nullable = false, length = 7)
    private YearMonth mes;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal valor;
}
