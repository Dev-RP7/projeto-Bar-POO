package br.com.nosdois.dto;

import br.com.nosdois.dominio.RegraDivisao;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** Perfil, casal e convite. */
public final class PerfilDtos {

    private PerfilDtos() {
    }

    public record PessoaResponse(Long id, String nome, boolean eu) {
    }

    /**
     * O perfil de quem está logado. Enquanto o casal tem uma pessoa só,
     * "convite" traz o código e o link para chamar a outra pessoa.
     */
    public record PerfilResponse(
            Long id,
            String nome,
            String email,
            Long casalId,
            RegraDivisao regraDivisao,
            java.util.List<PessoaResponse> pessoas,
            ConviteResponse convite
    ) {
    }

    public record ConviteResponse(String codigo, String link) {
    }

    /** O que aparece para quem abre o link de convite, antes de aceitar. */
    public record ConvitePublicoResponse(String codigo, String nomeDeQuemConvidou, boolean disponivel) {
    }

    public record AceitarConviteRequest(
            @NotBlank(message = "Informe o código") @Pattern(regexp = "[A-Za-z0-9]{6}", message = "O código tem 6 caracteres") String codigo
    ) {
    }

    public record AtualizarNomeRequest(
            @NotBlank(message = "Informe seu nome") @Size(max = 80, message = "Nome muito longo") String nome
    ) {
    }

    public record RegraDivisaoRequest(@NotNull(message = "Escolha a regra") RegraDivisao regra) {
    }

    public record TrocarSenhaRequest(
            @NotBlank(message = "Informe a senha atual") String senhaAtual,
            @NotBlank(message = "Crie uma senha") @Size(min = 8, max = 72, message = "A senha deve ter entre 8 e 72 caracteres") String novaSenha
    ) {
    }
}
