package br.com.nosdois.servico.calculo;

import br.com.nosdois.dominio.RegraDivisao;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Optional;

/**
 * Regras de cálculo do Nós Dois, sem banco e sem Spring, para serem testadas isoladamente.
 * Valores em BigDecimal com 2 casas, arredondando "meio para cima".
 */
public final class Calculadora {

    public static final BigDecimal ZERO = dinheiro(BigDecimal.ZERO);

    private Calculadora() {
    }

    public static BigDecimal dinheiro(BigDecimal valor) {
        return (valor == null ? BigDecimal.ZERO : valor).setScale(2, RoundingMode.HALF_UP);
    }

    public static BigDecimal soma(List<BigDecimal> valores) {
        return dinheiro(valores.stream().reduce(BigDecimal.ZERO, BigDecimal::add));
    }

    /**
     * Divide as contas do casal entre as pessoas.
     * Proporcional: parte = total × renda ÷ soma das rendas. Igual: partes iguais.
     * Soma das rendas zero: partes iguais. A última pessoa recebe o resto do arredondamento,
     * para as partes somarem exatamente o total.
     */
    public static List<BigDecimal> dividir(BigDecimal total, List<BigDecimal> rendas, RegraDivisao regra) {
        int n = rendas.size();
        if (n == 0) {
            return List.of();
        }
        BigDecimal totalD = dinheiro(total);
        BigDecimal somaRendas = soma(rendas);
        boolean igual = regra == RegraDivisao.IGUAL || somaRendas.signum() == 0;

        List<BigDecimal> partes = new ArrayList<>(n);
        BigDecimal acumulado = BigDecimal.ZERO;
        for (int i = 0; i < n - 1; i++) {
            BigDecimal parte = igual
                    ? totalD.divide(BigDecimal.valueOf(n), 2, RoundingMode.HALF_UP)
                    : totalD.multiply(dinheiro(rendas.get(i))).divide(somaRendas, 2, RoundingMode.HALF_UP);
            partes.add(parte);
            acumulado = acumulado.add(parte);
        }
        partes.add(dinheiro(totalD.subtract(acumulado)));
        return partes;
    }

    /** Renda de um mês: o registro daquele mês ou, se não houver, o último mês anterior. Sem nenhum, zero. */
    public static BigDecimal rendaDoMes(NavigableMap<YearMonth, BigDecimal> rendasPorMes, YearMonth mes) {
        Map.Entry<YearMonth, BigDecimal> registro = rendasPorMes.floorEntry(mes);
        return registro == null ? ZERO : dinheiro(registro.getValue());
    }

    /** Meses entre hoje e o prazo, no mínimo 1. */
    public static long mesesAtePrazo(YearMonth hoje, YearMonth prazo) {
        return Math.max(1, ChronoUnit.MONTHS.between(hoje, prazo));
    }

    /**
     * Parcela mensal de uma meta: (valor − guardado) ÷ meses até o prazo.
     * Vazia quando a meta não tem valor ou prazo, quando o prazo já passou ou quando foi alcançada.
     */
    public static Optional<BigDecimal> parcelaMensal(BigDecimal valorAlvo, BigDecimal guardado, YearMonth prazo, YearMonth hoje) {
        if (valorAlvo == null || prazo == null || prazo.isBefore(hoje)) {
            return Optional.empty();
        }
        BigDecimal falta = dinheiro(valorAlvo).subtract(dinheiro(guardado));
        if (falta.signum() <= 0) {
            return Optional.empty();
        }
        return Optional.of(falta.divide(BigDecimal.valueOf(mesesAtePrazo(hoje, prazo)), 2, RoundingMode.HALF_UP));
    }

    /** Progresso de 0 a 100 (sem passar de 100). Meta sem valor: zero. */
    public static int progresso(BigDecimal valorAlvo, BigDecimal guardado) {
        if (valorAlvo == null || valorAlvo.signum() <= 0) {
            return 0;
        }
        int pct = dinheiro(guardado).multiply(BigDecimal.valueOf(100)).divide(valorAlvo, 0, RoundingMode.DOWN).intValue();
        return Math.max(0, Math.min(100, pct));
    }

    /** Média mensal dos gastos considerando só meses com algum gasto. */
    public static BigDecimal mediaMensal(List<BigDecimal> totaisPorMes) {
        List<BigDecimal> comGasto = totaisPorMes.stream().filter(v -> v.signum() > 0).toList();
        if (comGasto.isEmpty()) {
            return ZERO;
        }
        return soma(comGasto).divide(BigDecimal.valueOf(comGasto.size()), 2, RoundingMode.HALF_UP);
    }
}
