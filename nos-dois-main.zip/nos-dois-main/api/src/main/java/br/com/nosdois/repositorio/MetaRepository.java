package br.com.nosdois.repositorio;

import br.com.nosdois.dominio.Casal;
import br.com.nosdois.dominio.Meta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface MetaRepository extends JpaRepository<Meta, Long> {

    List<Meta> findByCasalIdOrderByIdAsc(Long casalId);

    Optional<Meta> findByIdAndCasalId(Long id, Long casalId);

    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("update Meta m set m.casal = :destino where m.casal.id = :origem")
    void moverTodas(@Param("origem") Long origem, @Param("destino") Casal destino);
}
