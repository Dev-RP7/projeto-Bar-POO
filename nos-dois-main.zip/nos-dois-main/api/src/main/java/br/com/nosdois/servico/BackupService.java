package br.com.nosdois.servico;

import br.com.nosdois.dominio.Meta;
import br.com.nosdois.dominio.Renda;
import br.com.nosdois.repositorio.GastoRepository;
import br.com.nosdois.repositorio.MetaRepository;
import br.com.nosdois.repositorio.RendaRepository;
import br.com.nosdois.seguranca.UsuarioLogado;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Exporta tudo do casal num JSON que a pessoa pode guardar. */
@Service
public class BackupService {

    private final CasalService casalService;
    private final RendaRepository rendaRepository;
    private final GastoRepository gastoRepository;
    private final MetaRepository metaRepository;

    public BackupService(CasalService casalService, RendaRepository rendaRepository,
                         GastoRepository gastoRepository, MetaRepository metaRepository) {
        this.casalService = casalService;
        this.rendaRepository = rendaRepository;
        this.gastoRepository = gastoRepository;
        this.metaRepository = metaRepository;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> exportar(UsuarioLogado eu) {
        Map<String, Object> backup = new LinkedHashMap<>();
        backup.put("app", "Nós Dois");
        backup.put("geradoEm", LocalDateTime.now());
        backup.put("perfil", casalService.perfil(eu.usuarioId()));
        backup.put("rendas", rendaRepository.findByCasalId(eu.casalId()).stream()
                .map(r -> Map.of("pessoa", r.getUsuario().getNome(), "mes", r.getMes().toString(), "valor", r.getValor()))
                .toList());
        backup.put("gastos", gastoRepository.findByCasalId(eu.casalId()).stream()
                .map(GastoService::paraResponse).toList());
        backup.put("metas", metaRepository.findByCasalIdOrderByIdAsc(eu.casalId()).stream()
                .map(BackupService::meta).toList());
        return backup;
    }

    private static Map<String, Object> meta(Meta m) {
        Map<String, Object> mapa = new LinkedHashMap<>();
        mapa.put("nome", m.getNome());
        mapa.put("valorAlvo", m.getValorAlvo());
        mapa.put("prazo", m.getPrazo() == null ? null : m.getPrazo().toString());
        List<Map<String, Object>> depositos = m.getDepositos().stream()
                .map(d -> Map.<String, Object>of("data", d.getData().toString(), "valor", d.getValor(), "por", d.getCriadoPor().getNome()))
                .toList();
        mapa.put("depositos", depositos);
        return mapa;
    }
}
