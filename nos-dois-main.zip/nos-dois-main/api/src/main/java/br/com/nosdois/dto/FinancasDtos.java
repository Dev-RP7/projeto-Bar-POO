package br.com.nosdois.dto;

import br.com.nosdois.dominio.Categoria;
import br.com.nosdois.dominio.RegraDivisao;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;

/** Rendas, gastos, mês, histórico e metas. Valores em reais com 2 casas. */
public final class FinancasDtos {

    private FinancasDtos() {
    }

    // ---------- Renda ----------

    public record RendaRequest(
            @NotNull(message = "Informe o valor")
            @PositiveOrZero(message = "A renda não pode ser negativa")
            @Digits(integer = 10, fraction = 2, message = "Valor inválido") BigDecimal valor
    ) {
    }

    // ---------- Gastos ----------

    public record GastoRequest(
            @NotNull(message = "Informe a data") LocalDate data,
            @NotBlank(message = "Descreva o gasto") @Size(max = 120, message = "Descrição muito longa") String descricao,
            @NotNull(message = "Informe o valor")
            @Positive(message = "O valor deve ser maior que zero")
            @Digits(integer = 10, fraction = 2, message = "Valor inválido") BigDecimal valor,
            @NotNull(message = "Escolha a categoria") Categoria categoria,
            /** null = conta do casal; id de uma pessoa = conta só dela. */
            Long donoId
    ) {
    }

    public record GastoResponse(
            Long id, LocalDate data, String descricao, BigDecimal valor,
            Categoria categoria, String categoriaRotulo,
            Long donoId, String donoNome,
            Long criadoPorId, String criadoPorNome
    ) {
    }

    public record DiaGastos(LocalDate data, BigDecimal total, List<GastoResponse> gastos) {
    }

    public record GastosMesResponse(YearMonth mes, BigDecimal total, List<DiaGastos> dias) {
    }

    public record CategoriaInfo(Categoria categoria, String rotulo) {
    }

    // ---------- Mês ----------

    public record PessoaMes(
            Long id, String nome, boolean eu,
            BigDecimal renda,
            /** true quando o mês não tem renda registrada e o valor foi repetido de um mês anterior. */
            boolean rendaRepetida,
            BigDecimal parteContasCasal,
            BigDecimal contasIndividuais,
            BigDecimal totalPaga,
            BigDecimal sobra
    ) {
    }

    public record CategoriaTotal(Categoria categoria, String rotulo, BigDecimal total) {
    }

    public record ReservaEmergencia(BigDecimal mediaMensalGastos, BigDecimal minimo, BigDecimal maximo) {
    }

    public record ResumoMesResponse(
            YearMonth mes,
            RegraDivisao regraDivisao,
            List<PessoaMes> pessoas,
            BigDecimal totalRendas,
            BigDecimal contasCasal,
            BigDecimal totalGastos,
            BigDecimal sobraCasal,
            BigDecimal depositosNoMes,
            BigDecimal disponivelParaGuardar,
            List<CategoriaTotal> porCategoria,
            ReservaEmergencia reserva
    ) {
    }

    // ---------- Histórico ----------

    public record LinhaHistorico(
            String periodo, String rotulo,
            BigDecimal entrou, BigDecimal saiu, BigDecimal sobrou, BigDecimal guardado,
            boolean futuro
    ) {
    }

    public record HistoricoResponse(String tipo, String periodo, List<LinhaHistorico> linhas, LinhaHistorico total) {
    }

    // ---------- Metas ----------

    public record MetaRequest(
            @NotBlank(message = "Dê um nome à meta") @Size(max = 80, message = "Nome muito longo") String nome,
            @Positive(message = "O valor deve ser maior que zero")
            @Digits(integer = 10, fraction = 2, message = "Valor inválido") BigDecimal valorAlvo,
            /** Mês do prazo, ex.: "2027-06". Opcional. */
            YearMonth prazo
    ) {
    }

    public record DepositoRequest(
            @NotNull(message = "Informe o valor")
            @Positive(message = "O valor deve ser maior que zero")
            @Digits(integer = 10, fraction = 2, message = "Valor inválido") BigDecimal valor,
            /** Opcional: hoje quando vazio. */
            LocalDate data
    ) {
    }

    public record DepositoResponse(Long id, LocalDate data, BigDecimal valor, String criadoPorNome) {
    }

    public record ParteResponse(Long id, String nome, BigDecimal valor) {
    }

    public record MetaResponse(
            Long id, String nome, BigDecimal valorAlvo, YearMonth prazo,
            BigDecimal guardado, int progresso, boolean alcancada, boolean prazoVencido,
            BigDecimal parcelaMensal, List<ParteResponse> partesDaParcela,
            List<DepositoResponse> depositos
    ) {
    }

    public record JuntosResponse(
            BigDecimal totalGuardado,
            BigDecimal disponivelParaGuardar,
            List<MetaResponse> metas,
            List<String> ideias
    ) {
    }
}
