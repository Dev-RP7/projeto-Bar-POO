package br.com.nosdois.web;

import br.com.nosdois.dominio.Categoria;
import br.com.nosdois.dto.FinancasDtos.*;
import br.com.nosdois.seguranca.UsuarioLogado;
import br.com.nosdois.servico.*;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.Clock;
import java.time.Year;
import java.util.Arrays;
import java.util.List;

/** Mês, rendas, gastos, histórico e metas. Tudo é do casal de quem está logado. */
@RestController
public class FinancasController {

    private final ResumoService resumoService;
    private final RendaService rendaService;
    private final GastoService gastoService;
    private final HistoricoService historicoService;
    private final MetaService metaService;
    private final Clock clock;

    public FinancasController(ResumoService resumoService, RendaService rendaService, GastoService gastoService,
                              HistoricoService historicoService, MetaService metaService, Clock clock) {
        this.resumoService = resumoService;
        this.rendaService = rendaService;
        this.gastoService = gastoService;
        this.historicoService = historicoService;
        this.metaService = metaService;
        this.clock = clock;
    }

    // ---------- Mês ----------

    /** Resumo de um mês (AAAA-MM). Sem o parâmetro, o mês atual. */
    @GetMapping("/meses")
    public ResumoMesResponse mes(@AuthenticationPrincipal UsuarioLogado eu, @RequestParam(required = false) String mes) {
        return resumoService.resumo(eu.casalId(), eu.usuarioId(), Meses.ler(mes, clock));
    }

    /** Define a MINHA renda no mês. */
    @PutMapping("/rendas/{mes}")
    public ResumoMesResponse definirRenda(@AuthenticationPrincipal UsuarioLogado eu, @PathVariable String mes,
                                          @RequestBody @Valid RendaRequest req) {
        var ym = Meses.ler(mes, clock);
        rendaService.definir(eu, ym, req.valor());
        return resumoService.resumo(eu.casalId(), eu.usuarioId(), ym);
    }

    // ---------- Gastos ----------

    @GetMapping("/gastos")
    public GastosMesResponse gastos(@AuthenticationPrincipal UsuarioLogado eu, @RequestParam(required = false) String mes) {
        return gastoService.doMes(eu, Meses.ler(mes, clock));
    }

    @GetMapping("/gastos/categorias")
    public List<CategoriaInfo> categorias() {
        return Arrays.stream(Categoria.values()).map(c -> new CategoriaInfo(c, c.getRotulo())).toList();
    }

    @PostMapping("/gastos")
    public ResponseEntity<GastoResponse> criarGasto(@AuthenticationPrincipal UsuarioLogado eu, @RequestBody @Valid GastoRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(gastoService.criar(eu, req));
    }

    @PutMapping("/gastos/{id}")
    public GastoResponse atualizarGasto(@AuthenticationPrincipal UsuarioLogado eu, @PathVariable Long id,
                                        @RequestBody @Valid GastoRequest req) {
        return gastoService.atualizar(eu, id, req);
    }

    @DeleteMapping("/gastos/{id}")
    public ResponseEntity<Void> excluirGasto(@AuthenticationPrincipal UsuarioLogado eu, @PathVariable Long id) {
        gastoService.excluir(eu, id);
        return ResponseEntity.noContent().build();
    }

    // ---------- Histórico ----------

    @GetMapping("/historico/dias")
    public HistoricoResponse porDia(@AuthenticationPrincipal UsuarioLogado eu, @RequestParam(required = false) String mes) {
        return historicoService.porDia(eu.casalId(), Meses.ler(mes, clock));
    }

    @GetMapping("/historico/meses")
    public HistoricoResponse porMes(@AuthenticationPrincipal UsuarioLogado eu, @RequestParam(required = false) Integer ano) {
        return historicoService.porMes(eu.casalId(), ano != null ? ano : Year.now(clock).getValue());
    }

    @GetMapping("/historico/anos")
    public HistoricoResponse porAno(@AuthenticationPrincipal UsuarioLogado eu) {
        return historicoService.porAno(eu.casalId());
    }

    // ---------- Juntos (metas) ----------

    @GetMapping("/juntos")
    public JuntosResponse juntos(@AuthenticationPrincipal UsuarioLogado eu) {
        return metaService.juntos(eu);
    }

    @PostMapping("/metas")
    public ResponseEntity<MetaResponse> criarMeta(@AuthenticationPrincipal UsuarioLogado eu, @RequestBody @Valid MetaRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(metaService.criar(eu, req));
    }

    @PutMapping("/metas/{id}")
    public MetaResponse atualizarMeta(@AuthenticationPrincipal UsuarioLogado eu, @PathVariable Long id,
                                      @RequestBody @Valid MetaRequest req) {
        return metaService.atualizar(eu, id, req);
    }

    @DeleteMapping("/metas/{id}")
    public ResponseEntity<Void> excluirMeta(@AuthenticationPrincipal UsuarioLogado eu, @PathVariable Long id) {
        metaService.excluir(eu, id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/metas/{id}/depositos")
    public ResponseEntity<MetaResponse> depositar(@AuthenticationPrincipal UsuarioLogado eu, @PathVariable Long id,
                                                  @RequestBody @Valid DepositoRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(metaService.depositar(eu, id, req));
    }

    @DeleteMapping("/metas/{id}/depositos/{depositoId}")
    public MetaResponse excluirDeposito(@AuthenticationPrincipal UsuarioLogado eu, @PathVariable Long id,
                                        @PathVariable Long depositoId) {
        return metaService.excluirDeposito(eu, id, depositoId);
    }
}
