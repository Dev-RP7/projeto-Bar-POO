package br.com.nosdois.dominio;

/** Categorias iniciais de gasto. */
public enum Categoria {
    MORADIA("Moradia"),
    MERCADO("Mercado"),
    CONTAS_DA_CASA("Contas da casa"),
    TRANSPORTE("Transporte"),
    SAUDE("Saúde"),
    LAZER("Lazer"),
    EDUCACAO("Educação"),
    OUTROS("Outros");

    private final String rotulo;

    Categoria(String rotulo) {
        this.rotulo = rotulo;
    }

    public String getRotulo() {
        return rotulo;
    }
}
