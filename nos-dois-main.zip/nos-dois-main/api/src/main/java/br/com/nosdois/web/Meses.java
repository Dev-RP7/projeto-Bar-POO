package br.com.nosdois.web;

import br.com.nosdois.excecao.ApiException;
import org.springframework.http.HttpStatus;

import java.time.Clock;
import java.time.YearMonth;
import java.time.format.DateTimeParseException;

/** Converte "AAAA-MM" da URL em YearMonth (vazio = mês atual). */
final class Meses {

    private Meses() {
    }

    static YearMonth ler(String texto, Clock clock) {
        if (texto == null || texto.isBlank()) {
            return YearMonth.now(clock);
        }
        try {
            return YearMonth.parse(texto.trim());
        } catch (DateTimeParseException e) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "MES_INVALIDO", "Mês inválido. Use o formato AAAA-MM.");
        }
    }
}
