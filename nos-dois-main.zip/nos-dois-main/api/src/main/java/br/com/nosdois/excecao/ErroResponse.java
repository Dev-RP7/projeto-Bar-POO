package br.com.nosdois.excecao;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.LocalDateTime;
import java.util.List;

/** Formato padrão de todos os erros da API. */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ErroResponse(
        LocalDateTime timestamp,
        int status,
        String codigo,
        String mensagem,
        String caminho,
        List<CampoErro> campos
) {
    public record CampoErro(String campo, String mensagem) {
    }
}
