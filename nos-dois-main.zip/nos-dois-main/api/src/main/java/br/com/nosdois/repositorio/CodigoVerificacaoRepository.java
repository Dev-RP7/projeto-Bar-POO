package br.com.nosdois.repositorio;

import br.com.nosdois.dominio.CodigoVerificacao;
import br.com.nosdois.dominio.TipoCodigo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.Optional;

public interface CodigoVerificacaoRepository extends JpaRepository<CodigoVerificacao, Long> {

    /** Último código ainda não usado de um tipo. */
    Optional<CodigoVerificacao> findFirstByUsuarioIdAndTipoAndUsadoFalseOrderByIdDesc(Long usuarioId, TipoCodigo tipo);

    /** Quantos códigos foram enviados desde um instante (limite de reenvios). */
    long countByUsuarioIdAndTipoAndCriadoEmAfter(Long usuarioId, TipoCodigo tipo, LocalDateTime desde);

    Optional<CodigoVerificacao> findFirstByUsuarioIdAndTipoOrderByIdDesc(Long usuarioId, TipoCodigo tipo);

    @Modifying
    @Query("update CodigoVerificacao c set c.usado = true where c.usuario.id = :usuarioId and c.tipo = :tipo and c.usado = false")
    void invalidarAbertos(@Param("usuarioId") Long usuarioId, @Param("tipo") TipoCodigo tipo);
}
