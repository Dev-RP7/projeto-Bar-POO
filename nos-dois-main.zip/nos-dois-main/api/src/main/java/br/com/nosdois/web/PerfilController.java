package br.com.nosdois.web;

import br.com.nosdois.dto.PerfilDtos.*;
import br.com.nosdois.seguranca.UsuarioLogado;
import br.com.nosdois.servico.BackupService;
import br.com.nosdois.servico.CasalService;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;

/** Perfil, convite e vínculo do casal, e backup. */
@RestController
public class PerfilController {

    private final CasalService casalService;
    private final BackupService backupService;

    public PerfilController(CasalService casalService, BackupService backupService) {
        this.casalService = casalService;
        this.backupService = backupService;
    }

    @GetMapping("/perfil")
    public PerfilResponse perfil(@AuthenticationPrincipal UsuarioLogado eu) {
        return casalService.perfil(eu.usuarioId());
    }

    @PatchMapping("/perfil/nome")
    public PerfilResponse alterarNome(@AuthenticationPrincipal UsuarioLogado eu, @RequestBody @Valid AtualizarNomeRequest req) {
        return casalService.alterarNome(eu.usuarioId(), req.nome());
    }

    @PatchMapping("/perfil/senha")
    public ResponseEntity<Void> trocarSenha(@AuthenticationPrincipal UsuarioLogado eu, @RequestBody @Valid TrocarSenhaRequest req) {
        casalService.trocarSenha(eu.usuarioId(), req.senhaAtual(), req.novaSenha());
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/perfil/regra-divisao")
    public PerfilResponse alterarRegra(@AuthenticationPrincipal UsuarioLogado eu, @RequestBody @Valid RegraDivisaoRequest req) {
        return casalService.alterarRegra(eu.usuarioId(), req.regra());
    }

    /** Aceita o convite da outra pessoa (feito no perfil, já com a própria conta). */
    @PostMapping("/perfil/convite/aceitar")
    public PerfilResponse aceitarConvite(@AuthenticationPrincipal UsuarioLogado eu, @RequestBody @Valid AceitarConviteRequest req) {
        return casalService.aceitarConvite(eu.usuarioId(), req.codigo());
    }

    @PostMapping("/perfil/sair-do-casal")
    public PerfilResponse sairDoCasal(@AuthenticationPrincipal UsuarioLogado eu) {
        return casalService.sairDoCasal(eu.usuarioId());
    }

    /** Rota pública: o que aparece ao abrir o link de convite. */
    @GetMapping("/convites/{codigo}")
    public ConvitePublicoResponse convite(@PathVariable String codigo) {
        return casalService.convitePublico(codigo);
    }

    @GetMapping("/backup")
    public ResponseEntity<Map<String, Object>> backup(@AuthenticationPrincipal UsuarioLogado eu) {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"nos-dois-backup-" + LocalDate.now() + ".json\"")
                .body(backupService.exportar(eu));
    }
}
