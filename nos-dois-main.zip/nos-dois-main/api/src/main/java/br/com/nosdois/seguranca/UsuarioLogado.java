package br.com.nosdois.seguranca;

/**
 * Quem está fazendo a requisição. O casalId é lido do banco a cada requisição,
 * então muda na hora em que um convite é aceito.
 */
public record UsuarioLogado(Long usuarioId, Long casalId, String nome, String email) {
}
