package br.com.nosdois.servico;

import br.com.nosdois.dominio.Categoria;
import br.com.nosdois.dominio.Deposito;
import br.com.nosdois.dominio.Gasto;
import br.com.nosdois.dominio.Usuario;
import br.com.nosdois.dto.FinancasDtos.*;
import br.com.nosdois.repositorio.DepositoRepository;
import br.com.nosdois.repositorio.GastoRepository;
import br.com.nosdois.servico.calculo.Calculadora;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

/** Tela "Mês": quanto entrou, quanto cada um paga, quanto sobra e quanto dá para guardar. */
@Service
public class ResumoService {

    private static final int MESES_MEDIA_RESERVA = 6;

    private final ContextoCasal contextoCasal;
    private final GastoRepository gastoRepository;
    private final DepositoRepository depositoRepository;

    public ResumoService(ContextoCasal contextoCasal, GastoRepository gastoRepository, DepositoRepository depositoRepository) {
        this.contextoCasal = contextoCasal;
        this.gastoRepository = gastoRepository;
        this.depositoRepository = depositoRepository;
    }

    @Transactional(readOnly = true)
    public ResumoMesResponse resumo(Long casalId, Long euId, YearMonth mes) {
        ContextoCasal.Dados ctx = contextoCasal.carregar(casalId);
        List<Gasto> gastos = gastoRepository.doPeriodo(casalId, mes.atDay(1), mes.atEndOfMonth());

        BigDecimal contasCasal = Calculadora.soma(gastos.stream().filter(Gasto::isDoCasal).map(Gasto::getValor).toList());
        BigDecimal totalGastos = Calculadora.soma(gastos.stream().map(Gasto::getValor).toList());
        List<BigDecimal> rendas = ctx.rendasDoMes(mes);
        List<BigDecimal> partes = Calculadora.dividir(contasCasal, rendas, ctx.casal().getRegraDivisao());

        List<PessoaMes> pessoas = new ArrayList<>();
        for (int i = 0; i < ctx.pessoas().size(); i++) {
            Usuario p = ctx.pessoas().get(i);
            BigDecimal individuais = Calculadora.soma(gastos.stream()
                    .filter(g -> !g.isDoCasal() && g.getDono().getId().equals(p.getId()))
                    .map(Gasto::getValor).toList());
            BigDecimal totalPaga = partes.get(i).add(individuais);
            pessoas.add(new PessoaMes(
                    p.getId(), p.getNome(), p.getId().equals(euId),
                    rendas.get(i), ctx.rendaRepetida(p.getId(), mes),
                    partes.get(i), individuais, totalPaga, rendas.get(i).subtract(totalPaga)));
        }

        BigDecimal totalRendas = Calculadora.soma(rendas);
        BigDecimal sobraCasal = totalRendas.subtract(totalGastos);
        BigDecimal depositos = Calculadora.soma(depositoRepository.doPeriodo(casalId, mes.atDay(1), mes.atEndOfMonth())
                .stream().map(Deposito::getValor).toList());

        return new ResumoMesResponse(
                mes, ctx.casal().getRegraDivisao(), pessoas,
                totalRendas, contasCasal, totalGastos, sobraCasal,
                depositos, sobraCasal.subtract(depositos),
                porCategoria(gastos), reserva(casalId, mes));
    }

    /** Disponível para guardar no mês, usado pela tela Juntos. */
    @Transactional(readOnly = true)
    public BigDecimal disponivelParaGuardar(Long casalId, Long euId, YearMonth mes) {
        return resumo(casalId, euId, mes).disponivelParaGuardar();
    }

    private List<CategoriaTotal> porCategoria(List<Gasto> gastos) {
        Map<Categoria, BigDecimal> totais = gastos.stream().collect(Collectors.groupingBy(
                Gasto::getCategoria, () -> new EnumMap<>(Categoria.class),
                Collectors.reducing(BigDecimal.ZERO, Gasto::getValor, BigDecimal::add)));
        return totais.entrySet().stream()
                .map(e -> new CategoriaTotal(e.getKey(), e.getKey().getRotulo(), Calculadora.dinheiro(e.getValue())))
                .sorted(Comparator.comparing(CategoriaTotal::total).reversed())
                .toList();
    }

    /** Referência de reserva de emergência: 3 a 6 vezes a média mensal dos últimos 6 meses com gastos. */
    private ReservaEmergencia reserva(Long casalId, YearMonth mes) {
        YearMonth inicio = mes.minusMonths(MESES_MEDIA_RESERVA - 1);
        Map<YearMonth, BigDecimal> porMes = new HashMap<>();
        for (Gasto g : gastoRepository.doPeriodo(casalId, inicio.atDay(1), mes.atEndOfMonth())) {
            porMes.merge(YearMonth.from(g.getData()), g.getValor(), BigDecimal::add);
        }
        BigDecimal media = Calculadora.mediaMensal(new ArrayList<>(porMes.values()));
        return new ReservaEmergencia(media,
                Calculadora.dinheiro(media.multiply(BigDecimal.valueOf(3))),
                Calculadora.dinheiro(media.multiply(BigDecimal.valueOf(6))));
    }
}
