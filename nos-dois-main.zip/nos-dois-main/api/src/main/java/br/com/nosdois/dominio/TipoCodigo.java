package br.com.nosdois.dominio;

/** Para que serve um código de 6 dígitos enviado por e-mail. */
public enum TipoCodigo {
    VERIFICAR_EMAIL,
    RECUPERAR_SENHA
}
