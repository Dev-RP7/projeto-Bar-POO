package br.com.nosdois.seguranca;

import br.com.nosdois.repositorio.UsuarioRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

/** Lê "Authorization: Bearer <token>" e identifica o usuário. Criado no SecurityConfig. */
public class JwtFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final UsuarioRepository usuarioRepository;

    public JwtFilter(JwtService jwtService, UsuarioRepository usuarioRepository) {
        this.jwtService = jwtService;
        this.usuarioRepository = usuarioRepository;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String cabecalho = request.getHeader("Authorization");
        if (cabecalho != null && cabecalho.startsWith("Bearer ")) {
            Long usuarioId = jwtService.validar(cabecalho.substring(7));
            if (usuarioId != null) {
                usuarioRepository.findById(usuarioId)
                        .filter(u -> u.isEmailVerificado())
                        .ifPresent(u -> {
                            var logado = new UsuarioLogado(u.getId(), u.getCasal().getId(), u.getNome(), u.getEmail());
                            var auth = new UsernamePasswordAuthenticationToken(logado, null, List.of());
                            SecurityContextHolder.getContext().setAuthentication(auth);
                        });
            }
        }
        chain.doFilter(request, response);
    }
}
