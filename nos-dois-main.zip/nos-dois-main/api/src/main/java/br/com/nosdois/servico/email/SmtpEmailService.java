package br.com.nosdois.servico.email;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/**
 * Envio real por SMTP (Brevo, Resend, Gmail...). Ativo quando app.email.modo=smtp;
 * servidor, usuário e senha vêm de spring.mail.*.
 */
@Slf4j
@Service
@ConditionalOnProperty(name = "app.email.modo", havingValue = "smtp")
public class SmtpEmailService implements EmailService {

    private final JavaMailSender mailSender;
    private final String remetente;

    public SmtpEmailService(JavaMailSender mailSender, @Value("${app.email.remetente}") String remetente) {
        this.mailSender = mailSender;
        this.remetente = remetente;
    }

    @Override
    public void enviar(String para, String assunto, String texto) {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setFrom(remetente);
        msg.setTo(para);
        msg.setSubject(assunto);
        msg.setText(texto);
        try {
            mailSender.send(msg);
            log.info("E-mail '{}' enviado", assunto);
        } catch (MailException e) {
            log.error("Falha ao enviar e-mail '{}'", assunto, e);
            throw new IllegalStateException("Não foi possível enviar o e-mail agora.", e);
        }
    }
}
