package br.com.nosdois.servico;

import br.com.nosdois.dominio.RefreshToken;
import br.com.nosdois.dominio.Usuario;
import br.com.nosdois.excecao.ApiException;
import br.com.nosdois.repositorio.RefreshTokenRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.HexFormat;

/**
 * Tokens de renovação: aleatórios, de uso único (trocados a cada renovação) e guardados só como hash.
 * Se um token já usado aparecer de novo, todas as sessões da pessoa são encerradas.
 */
@Slf4j
@Service
public class SessaoService {

    private static final SecureRandom RANDOM = new SecureRandom();

    private final RefreshTokenRepository repositorio;
    private final Duration validade;

    public SessaoService(RefreshTokenRepository repositorio,
                         @Value("${app.jwt.validade-renovacao:30d}") Duration validade) {
        this.repositorio = repositorio;
        this.validade = validade;
    }

    @Transactional
    public String criar(Usuario usuario) {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);

        RefreshToken registro = new RefreshToken();
        registro.setUsuario(usuario);
        registro.setTokenHash(hash(token));
        registro.setExpiraEm(LocalDateTime.now().plus(validade));
        repositorio.save(registro);
        return token;
    }

    /** Consome o token e devolve o dono. O chamador cria um token novo. */
    @Transactional(noRollbackFor = ApiException.class)
    public Usuario consumir(String token) {
        RefreshToken registro = repositorio.findByTokenHash(hash(token))
                .orElseThrow(SessaoService::sessaoInvalida);
        if (registro.isRevogado()) {
            log.warn("Token de renovação reutilizado; encerrando sessões do usuário {}", registro.getUsuario().getId());
            repositorio.revogarTodos(registro.getUsuario().getId());
            throw sessaoInvalida();
        }
        if (registro.getExpiraEm().isBefore(LocalDateTime.now())) {
            throw sessaoInvalida();
        }
        registro.setRevogado(true);
        return registro.getUsuario();
    }

    @Transactional
    public void encerrar(String token) {
        repositorio.findByTokenHash(hash(token)).ifPresent(t -> t.setRevogado(true));
    }

    @Transactional
    public void encerrarTodas(Long usuarioId) {
        repositorio.revogarTodos(usuarioId);
    }

    private static ApiException sessaoInvalida() {
        return ApiException.naoAutorizado("SESSAO_EXPIRADA", "Sua sessão expirou. Entre de novo.");
    }

    static String hash(String token) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(token.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
