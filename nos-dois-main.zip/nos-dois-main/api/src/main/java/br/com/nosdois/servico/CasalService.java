package br.com.nosdois.servico;

import br.com.nosdois.dominio.Casal;
import br.com.nosdois.dominio.RegraDivisao;
import br.com.nosdois.dominio.Usuario;
import br.com.nosdois.dto.PerfilDtos.*;
import br.com.nosdois.excecao.ApiException;
import br.com.nosdois.repositorio.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.util.List;

/**
 * Perfil, convite e vínculo do casal.
 * Cada conta nasce com o próprio "casal" de uma pessoa. Ao aceitar um convite, quem aceita
 * entra no casal de quem convidou e leva junto tudo o que já tinha registrado.
 */
@Slf4j
@Service
public class CasalService {

    /** Sem 0/O e 1/I/L, para o código não ser confundido ao digitar. */
    private static final String ALFABETO = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
    private static final SecureRandom RANDOM = new SecureRandom();
    public static final int MAX_PESSOAS = 2;

    private final CasalRepository casalRepository;
    private final UsuarioRepository usuarioRepository;
    private final RendaRepository rendaRepository;
    private final GastoRepository gastoRepository;
    private final MetaRepository metaRepository;
    private final PasswordEncoder passwordEncoder;
    private final SessaoService sessaoService;
    private final String urlApp;

    public CasalService(CasalRepository casalRepository, UsuarioRepository usuarioRepository,
                        RendaRepository rendaRepository, GastoRepository gastoRepository,
                        MetaRepository metaRepository, PasswordEncoder passwordEncoder,
                        SessaoService sessaoService, @Value("${app.url:http://localhost:4200}") String urlApp) {
        this.casalRepository = casalRepository;
        this.usuarioRepository = usuarioRepository;
        this.rendaRepository = rendaRepository;
        this.gastoRepository = gastoRepository;
        this.metaRepository = metaRepository;
        this.passwordEncoder = passwordEncoder;
        this.sessaoService = sessaoService;
        this.urlApp = urlApp.replaceAll("/+$", "");
    }

    /** Cria um casal novo, de uma pessoa, com código de convite único. */
    @Transactional
    public Casal novoCasal() {
        return casalRepository.save(new Casal(novoCodigo()));
    }

    @Transactional(readOnly = true)
    public PerfilResponse perfil(Long usuarioId) {
        Usuario eu = buscarUsuario(usuarioId);
        Casal casal = eu.getCasal();
        List<Usuario> pessoas = usuarioRepository.findByCasalIdOrderByIdAsc(casal.getId());
        ConviteResponse convite = pessoas.size() < MAX_PESSOAS
                ? new ConviteResponse(casal.getCodigoConvite(), urlApp + "/convite/" + casal.getCodigoConvite())
                : null;
        return new PerfilResponse(
                eu.getId(), eu.getNome(), eu.getEmail(), casal.getId(), casal.getRegraDivisao(),
                pessoas.stream().map(p -> new PessoaResponse(p.getId(), p.getNome(), p.getId().equals(eu.getId()))).toList(),
                convite);
    }

    /** Dados mostrados na tela do link de convite (rota pública). */
    @Transactional(readOnly = true)
    public ConvitePublicoResponse convitePublico(String codigo) {
        Casal casal = casalRepository.findByCodigoConvite(codigo.toUpperCase())
                .orElseThrow(() -> ApiException.naoEncontrado("Convite"));
        List<Usuario> pessoas = usuarioRepository.findByCasalIdOrderByIdAsc(casal.getId());
        String quem = pessoas.isEmpty() ? null : pessoas.get(0).getNome();
        return new ConvitePublicoResponse(casal.getCodigoConvite(), quem, pessoas.size() < MAX_PESSOAS);
    }

    /** Entra no casal de quem convidou, levando rendas, gastos e metas. */
    @Transactional
    public PerfilResponse aceitarConvite(Long usuarioId, String codigo) {
        Usuario eu = buscarUsuario(usuarioId);
        Casal destino = casalRepository.findByCodigoConvite(codigo.toUpperCase())
                .orElseThrow(() -> ApiException.regra("CONVITE_INVALIDO", "Código de convite não encontrado."));
        Casal origem = eu.getCasal();

        if (destino.getId().equals(origem.getId())) {
            throw ApiException.regra("CONVITE_PROPRIO", "Esse é o seu próprio convite. Envie-o para a outra pessoa.");
        }
        if (usuarioRepository.countByCasalId(origem.getId()) > 1) {
            throw ApiException.regra("JA_TEM_PARCEIRO", "Você já está conectado(a) a alguém. Saia do casal antes de aceitar outro convite.");
        }
        if (usuarioRepository.countByCasalId(destino.getId()) >= MAX_PESSOAS) {
            throw ApiException.conflito("CASAL_COMPLETO", "Esse convite já foi usado.");
        }

        Long origemId = origem.getId();
        Long destinoId = destino.getId();

        // As mudanças em massa limpam a memória do Hibernate; por isso recarregamos as entidades depois.
        gastoRepository.moverTodos(origemId, destino);
        metaRepository.moverTodas(origemId, destino);
        rendaRepository.moverParaCasal(eu.getId(), destino);

        eu = buscarUsuario(usuarioId);
        destino = casalRepository.getReferenceById(destinoId);
        eu.setCasal(destino);
        usuarioRepository.saveAndFlush(eu);
        casalRepository.deleteById(origemId);

        // O código usado deixa de valer: se alguém sair do casal, um código novo é gerado.
        destino.setCodigoConvite(novoCodigo());
        log.info("Usuário {} entrou no casal {}", eu.getId(), destino.getId());
        return perfil(usuarioId);
    }

    /**
     * Sai do casal: a pessoa recomeça num casal só dela, levando a própria renda e os gastos
     * individuais. Os gastos do casal e as metas ficam com quem permanece.
     */
    @Transactional
    public PerfilResponse sairDoCasal(Long usuarioId) {
        Usuario eu = buscarUsuario(usuarioId);
        Casal antigo = eu.getCasal();
        if (usuarioRepository.countByCasalId(antigo.getId()) < MAX_PESSOAS) {
            throw ApiException.regra("SEM_PARCEIRO", "Você ainda não está conectado(a) a ninguém.");
        }
        Long antigoId = antigo.getId();
        Casal novo = novoCasal();
        casalRepository.flush();
        gastoRepository.moverIndividuais(eu.getId(), novo);
        rendaRepository.moverParaCasal(eu.getId(), novo);

        eu = buscarUsuario(usuarioId);
        eu.setCasal(casalRepository.getReferenceById(novo.getId()));
        casalRepository.getReferenceById(antigoId).setCodigoConvite(novoCodigo());
        log.info("Usuário {} saiu do casal {}", eu.getId(), antigo.getId());
        return perfil(usuarioId);
    }

    @Transactional
    public PerfilResponse alterarRegra(Long usuarioId, RegraDivisao regra) {
        buscarUsuario(usuarioId).getCasal().setRegraDivisao(regra);
        return perfil(usuarioId);
    }

    @Transactional
    public PerfilResponse alterarNome(Long usuarioId, String nome) {
        buscarUsuario(usuarioId).setNome(nome.trim());
        return perfil(usuarioId);
    }

    @Transactional
    public void trocarSenha(Long usuarioId, String senhaAtual, String novaSenha) {
        Usuario eu = buscarUsuario(usuarioId);
        if (!passwordEncoder.matches(senhaAtual, eu.getSenhaHash())) {
            throw ApiException.regra("SENHA_INCORRETA", "A senha atual está incorreta.");
        }
        eu.setSenhaHash(passwordEncoder.encode(novaSenha));
        sessaoService.encerrarTodas(eu.getId());
    }

    private Usuario buscarUsuario(Long id) {
        return usuarioRepository.findById(id).orElseThrow(() -> ApiException.naoEncontrado("Usuário"));
    }

    private String novoCodigo() {
        String codigo;
        do {
            StringBuilder sb = new StringBuilder(6);
            for (int i = 0; i < 6; i++) {
                sb.append(ALFABETO.charAt(RANDOM.nextInt(ALFABETO.length())));
            }
            codigo = sb.toString();
        } while (casalRepository.existsByCodigoConvite(codigo));
        return codigo;
    }
}
