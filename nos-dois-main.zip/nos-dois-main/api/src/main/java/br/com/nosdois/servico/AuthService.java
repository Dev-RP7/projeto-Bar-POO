package br.com.nosdois.servico;

import br.com.nosdois.dominio.TipoCodigo;
import br.com.nosdois.dominio.Usuario;
import br.com.nosdois.dto.AuthDtos.*;
import br.com.nosdois.excecao.ApiException;
import br.com.nosdois.repositorio.UsuarioRepository;
import br.com.nosdois.seguranca.JwtService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Locale;

/** Cadastro, verificação de e-mail, login, sessão e recuperação de senha. */
@Slf4j
@Service
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final CodigoService codigoService;
    private final SessaoService sessaoService;
    private final CasalService casalService;
    private final JwtService jwtService;

    public AuthService(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder,
                       CodigoService codigoService, SessaoService sessaoService,
                       CasalService casalService, JwtService jwtService) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
        this.codigoService = codigoService;
        this.sessaoService = sessaoService;
        this.casalService = casalService;
        this.jwtService = jwtService;
    }

    /** Cria a conta (ainda não verificada) e envia o código por e-mail. */
    @Transactional
    public MensagemResponse cadastrar(CadastroRequest req) {
        String email = normalizar(req.email());
        if (usuarioRepository.existsByEmailIgnoreCase(email)) {
            throw ApiException.conflito("EMAIL_EM_USO", "Já existe uma conta com esse e-mail. Entre ou recupere a senha.");
        }
        Usuario usuario = new Usuario();
        usuario.setNome(req.nome().trim());
        usuario.setEmail(email);
        usuario.setSenhaHash(passwordEncoder.encode(req.senha()));
        usuario.setCasal(casalService.novoCasal());
        usuarioRepository.save(usuario);
        codigoService.enviar(usuario, TipoCodigo.VERIFICAR_EMAIL);
        log.info("Conta {} criada", usuario.getId());
        return new MensagemResponse("Enviamos um código de 6 números para " + email + ".");
    }

    /** Confere o código; a conta fica ativa e a pessoa já entra. */
    @Transactional(noRollbackFor = ApiException.class)
    public SessaoResponse verificarEmail(VerificarRequest req) {
        Usuario usuario = usuarioRepository.findByEmailIgnoreCase(normalizar(req.email()))
                .orElseThrow(() -> ApiException.regra("CODIGO_INVALIDO", "Código incorreto."));
        if (!usuario.isEmailVerificado()) {
            codigoService.validar(usuario, TipoCodigo.VERIFICAR_EMAIL, req.codigo());
            usuario.setEmailVerificado(true);
        }
        return sessao(usuario);
    }

    /** Reenvia o código. Responde igual para e-mail inexistente, para não revelar quem tem conta. */
    @Transactional
    public MensagemResponse reenviarCodigo(EmailRequest req) {
        usuarioRepository.findByEmailIgnoreCase(normalizar(req.email()))
                .filter(u -> !u.isEmailVerificado())
                .ifPresent(u -> codigoService.enviar(u, TipoCodigo.VERIFICAR_EMAIL));
        return new MensagemResponse("Se houver uma conta aguardando verificação, um novo código foi enviado.");
    }

    /** noRollbackFor: na conta não verificada, o código novo precisa ser gravado mesmo com o 403. */
    @Transactional(noRollbackFor = ApiException.class)
    public SessaoResponse login(LoginRequest req) {
        Usuario usuario = usuarioRepository.findByEmailIgnoreCase(normalizar(req.email()))
                .filter(u -> passwordEncoder.matches(req.senha(), u.getSenhaHash()))
                .orElseThrow(() -> ApiException.naoAutorizado("CREDENCIAIS_INVALIDAS", "E-mail ou senha incorretos."));
        if (!usuario.isEmailVerificado()) {
            try {
                codigoService.enviar(usuario, TipoCodigo.VERIFICAR_EMAIL);
            } catch (ApiException limite) {
                // Um código recente ainda vale; a pessoa só precisa digitá-lo.
            }
            throw ApiException.proibido("EMAIL_NAO_VERIFICADO", "Confirme seu e-mail com o código que enviamos.");
        }
        log.info("Login do usuário {}", usuario.getId());
        return sessao(usuario);
    }

    /** Troca o token de renovação por uma sessão nova. */
    @Transactional(noRollbackFor = ApiException.class)
    public SessaoResponse renovar(RenovarRequest req) {
        return sessao(sessaoService.consumir(req.refreshToken()));
    }

    public void sair(RenovarRequest req) {
        sessaoService.encerrar(req.refreshToken());
    }

    /** Sempre a mesma resposta, exista ou não a conta (inclusive no limite de envios). */
    @Transactional(noRollbackFor = ApiException.class)
    public MensagemResponse esqueciSenha(EmailRequest req) {
        usuarioRepository.findByEmailIgnoreCase(normalizar(req.email())).ifPresent(u -> {
            try {
                codigoService.enviar(u, TipoCodigo.RECUPERAR_SENHA);
            } catch (ApiException limite) {
                log.info("Limite de códigos de recuperação atingido para o usuário {}", u.getId());
            }
        });
        return new MensagemResponse("Se houver uma conta com esse e-mail, enviamos um código.");
    }

    /** Define a nova senha, confirma o e-mail (o código prova que a pessoa o recebe) e encerra as outras sessões. */
    @Transactional(noRollbackFor = ApiException.class)
    public SessaoResponse redefinirSenha(RedefinirSenhaRequest req) {
        Usuario usuario = usuarioRepository.findByEmailIgnoreCase(normalizar(req.email()))
                .orElseThrow(() -> ApiException.regra("CODIGO_INVALIDO", "Código incorreto."));
        codigoService.validar(usuario, TipoCodigo.RECUPERAR_SENHA, req.codigo());
        usuario.setSenhaHash(passwordEncoder.encode(req.novaSenha()));
        usuario.setEmailVerificado(true);
        sessaoService.encerrarTodas(usuario.getId());
        log.info("Senha redefinida para o usuário {}", usuario.getId());
        return sessao(usuario);
    }

    private SessaoResponse sessao(Usuario usuario) {
        return new SessaoResponse(
                jwtService.gerar(usuario.getId()),
                sessaoService.criar(usuario),
                jwtService.validadeEmSegundos(),
                casalService.perfil(usuario.getId()));
    }

    private static String normalizar(String email) {
        return email.trim().toLowerCase(Locale.ROOT);
    }
}
