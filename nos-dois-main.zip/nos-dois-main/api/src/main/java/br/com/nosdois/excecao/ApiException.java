package br.com.nosdois.excecao;

import org.springframework.http.HttpStatus;

/**
 * Erro de negócio com status HTTP e um código estável que o app pode tratar
 * (ex.: EMAIL_NAO_VERIFICADO leva para a tela de verificação).
 */
public class ApiException extends RuntimeException {

    private final HttpStatus status;
    private final String codigo;

    public ApiException(HttpStatus status, String codigo, String mensagem) {
        super(mensagem);
        this.status = status;
        this.codigo = codigo;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public String getCodigo() {
        return codigo;
    }

    public static ApiException naoEncontrado(String oQue) {
        return new ApiException(HttpStatus.NOT_FOUND, "NAO_ENCONTRADO", oQue + " não encontrado(a).");
    }

    public static ApiException conflito(String codigo, String mensagem) {
        return new ApiException(HttpStatus.CONFLICT, codigo, mensagem);
    }

    public static ApiException regra(String codigo, String mensagem) {
        return new ApiException(HttpStatus.UNPROCESSABLE_CONTENT, codigo, mensagem);
    }

    public static ApiException proibido(String codigo, String mensagem) {
        return new ApiException(HttpStatus.FORBIDDEN, codigo, mensagem);
    }

    public static ApiException naoAutorizado(String codigo, String mensagem) {
        return new ApiException(HttpStatus.UNAUTHORIZED, codigo, mensagem);
    }

    public static ApiException muitasTentativas(String mensagem) {
        return new ApiException(HttpStatus.TOO_MANY_REQUESTS, "MUITAS_TENTATIVAS", mensagem);
    }
}
