package br.com.nosdois.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;
import java.time.ZoneId;

/** "Hoje" no fuso do casal. Um Clock injetável também deixa os testes controlarem a data. */
@Configuration
public class ClockConfig {

    @Bean
    public Clock clock(@Value("${app.fuso:America/Sao_Paulo}") String fuso) {
        return Clock.system(ZoneId.of(fuso));
    }
}
