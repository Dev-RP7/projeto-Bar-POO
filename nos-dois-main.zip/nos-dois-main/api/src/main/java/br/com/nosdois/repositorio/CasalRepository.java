package br.com.nosdois.repositorio;

import br.com.nosdois.dominio.Casal;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CasalRepository extends JpaRepository<Casal, Long> {

    Optional<Casal> findByCodigoConvite(String codigoConvite);

    boolean existsByCodigoConvite(String codigoConvite);
}
