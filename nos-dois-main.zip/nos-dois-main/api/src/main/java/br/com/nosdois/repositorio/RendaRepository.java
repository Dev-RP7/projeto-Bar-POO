package br.com.nosdois.repositorio;

import br.com.nosdois.dominio.Casal;
import br.com.nosdois.dominio.Renda;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface RendaRepository extends JpaRepository<Renda, Long> {

    /** Todas as rendas de uma pessoa; o cálculo escolhe a do mês ou a última anterior. */
    List<Renda> findByUsuarioIdOrderByMesAsc(Long usuarioId);

    Optional<Renda> findByUsuarioIdAndMes(Long usuarioId, java.time.YearMonth mes);

    List<Renda> findByCasalId(Long casalId);

    /** As rendas acompanham a pessoa quando ela entra ou sai de um casal. */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("update Renda r set r.casal = :casal where r.usuario.id = :usuarioId")
    void moverParaCasal(@Param("usuarioId") Long usuarioId, @Param("casal") Casal casal);
}
