package br.com.nosdois.servico.calculo;

import br.com.nosdois.dominio.RegraDivisao;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.YearMonth;
import java.util.List;
import java.util.TreeMap;

import static org.assertj.core.api.Assertions.assertThat;

class CalculadoraTest {

    private static BigDecimal r(String valor) {
        return new BigDecimal(valor);
    }

    @Test
    void casoDoAluguelDoDocumento() {
        // Aluguel de R$ 1.600,00, rendas de R$ 5.000,00 e R$ 3.000,00, divisão proporcional.
        List<BigDecimal> partes = Calculadora.dividir(r("1600"), List.of(r("5000"), r("3000")), RegraDivisao.PROPORCIONAL);
        assertThat(partes).containsExactly(r("1000.00"), r("600.00"));
    }

    @Test
    void divisaoIgualDaMetadeParaCada() {
        assertThat(Calculadora.dividir(r("1600"), List.of(r("5000"), r("3000")), RegraDivisao.IGUAL))
                .containsExactly(r("800.00"), r("800.00"));
    }

    @Test
    void rendasZeradasDividemAoMeio() {
        assertThat(Calculadora.dividir(r("100"), List.of(r("0"), r("0")), RegraDivisao.PROPORCIONAL))
                .containsExactly(r("50.00"), r("50.00"));
    }

    @Test
    void arredondamentoSempreFechaOTotal() {
        // 100 ÷ 3 não é exato: as partes precisam somar exatamente 100,00.
        List<BigDecimal> partes = Calculadora.dividir(r("100"), List.of(r("1000"), r("2000")), RegraDivisao.PROPORCIONAL);
        assertThat(partes).containsExactly(r("33.33"), r("66.67"));
        assertThat(partes.get(0).add(partes.get(1))).isEqualByComparingTo("100.00");

        List<BigDecimal> igual = Calculadora.dividir(r("0.01"), List.of(r("1"), r("1")), RegraDivisao.IGUAL);
        assertThat(igual.get(0).add(igual.get(1))).isEqualByComparingTo("0.01");
    }

    @Test
    void pessoaSozinhaPagaTudo() {
        assertThat(Calculadora.dividir(r("250"), List.of(r("4000")), RegraDivisao.PROPORCIONAL))
                .containsExactly(r("250.00"));
    }

    @Test
    void rendaDeMesSemRegistroRepeteOUltimoAnterior() {
        TreeMap<YearMonth, BigDecimal> rendas = new TreeMap<>();
        rendas.put(YearMonth.of(2026, 3), r("4000"));
        rendas.put(YearMonth.of(2026, 6), r("4500"));

        assertThat(Calculadora.rendaDoMes(rendas, YearMonth.of(2026, 2))).isEqualByComparingTo("0");
        assertThat(Calculadora.rendaDoMes(rendas, YearMonth.of(2026, 3))).isEqualByComparingTo("4000");
        assertThat(Calculadora.rendaDoMes(rendas, YearMonth.of(2026, 5))).isEqualByComparingTo("4000");
        assertThat(Calculadora.rendaDoMes(rendas, YearMonth.of(2026, 9))).isEqualByComparingTo("4500");
    }

    @Test
    void parcelaMensalDaMeta() {
        YearMonth hoje = YearMonth.of(2026, 10);
        // Faltam 1.200 em 6 meses (outubro -> abril) = 200 por mês.
        assertThat(Calculadora.parcelaMensal(r("2000"), r("800"), YearMonth.of(2027, 4), hoje)).contains(r("200.00"));
        // Prazo no mês atual conta como 1 mês.
        assertThat(Calculadora.parcelaMensal(r("500"), r("0"), hoje, hoje)).contains(r("500.00"));
    }

    @Test
    void semParcelaQuandoNaoSeAplica() {
        YearMonth hoje = YearMonth.of(2026, 10);
        assertThat(Calculadora.parcelaMensal(null, r("0"), YearMonth.of(2027, 1), hoje)).isEmpty();          // sem valor
        assertThat(Calculadora.parcelaMensal(r("1000"), r("0"), null, hoje)).isEmpty();                       // sem prazo
        assertThat(Calculadora.parcelaMensal(r("1000"), r("0"), YearMonth.of(2026, 9), hoje)).isEmpty();      // prazo passou
        assertThat(Calculadora.parcelaMensal(r("1000"), r("1000"), YearMonth.of(2027, 1), hoje)).isEmpty();   // alcançada
    }

    @Test
    void progressoLimitadoA100() {
        assertThat(Calculadora.progresso(r("1000"), r("250"))).isEqualTo(25);
        assertThat(Calculadora.progresso(r("1000"), r("1500"))).isEqualTo(100);
        assertThat(Calculadora.progresso(null, r("50"))).isZero();
    }

    @Test
    void mediaMensalIgnoraMesesSemGasto() {
        assertThat(Calculadora.mediaMensal(List.of(r("1000"), r("0"), r("2000")))).isEqualByComparingTo("1500");
        assertThat(Calculadora.mediaMensal(List.of())).isEqualByComparingTo("0");
    }
}
