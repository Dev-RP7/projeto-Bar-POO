package br.com.nosdois;

import com.jayway.jsonpath.JsonPath;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.time.YearMonth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Fluxo completo: duas contas, convite pelo perfil, cálculo do mês, metas e sessão.
 * Sem @Transactional: cada requisição grava de verdade, como em produção (e-mails diferentes por teste).
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Import(EmailCapturado.class)
class FluxoDoCasalTest {

    private static final String MES = YearMonth.now().toString();

    @Autowired
    private MockMvc mvc;

    @Autowired
    private EmailCapturado.Caixa caixa;

    @Test
    void casalCompleto() throws Exception {
        // 1) Ana cria a conta: fica pendente até digitar o código do e-mail.
        cadastrar("Ana", "ana@teste.com");
        json(post("/auth/login"), null, "{\"email\":\"ana@teste.com\",\"senha\":\"senha-forte-1\"}")
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.codigo").value("EMAIL_NAO_VERIFICADO"));
        json(post("/auth/verificar"), null, "{\"email\":\"ana@teste.com\",\"codigo\":\"000000\"}")
                .andExpect(status().isUnprocessableContent())
                .andExpect(jsonPath("$.codigo").value("CODIGO_INVALIDO"));
        String sessaoAna = verificar("ana@teste.com");
        String tokenAna = JsonPath.read(sessaoAna, "$.accessToken");
        String convite = JsonPath.read(sessaoAna, "$.perfil.convite.codigo");
        assertThat((String) JsonPath.read(sessaoAna, "$.perfil.convite.link")).endsWith("/convite/" + convite);

        // 2) Ana usa o app sozinha: renda e aluguel do casal.
        json(put("/rendas/" + MES), tokenAna, "{\"valor\":5000}").andExpect(status().isOk());
        json(post("/gastos"), tokenAna, gasto("Aluguel", "1600", "MORADIA", null)).andExpect(status().isCreated());

        // 3) Bruno cria a própria conta e registra renda e um gasto só dele.
        cadastrar("Bruno", "bruno@teste.com");
        String sessaoBruno = verificar("bruno@teste.com");
        String tokenBruno = JsonPath.read(sessaoBruno, "$.accessToken");
        Integer idBruno = JsonPath.read(sessaoBruno, "$.perfil.id");
        json(put("/rendas/" + MES), tokenBruno, "{\"valor\":3000}").andExpect(status().isOk());
        json(post("/gastos"), tokenBruno, gasto("Academia", "100", "SAUDE", idBruno)).andExpect(status().isCreated());

        // 4) O link de convite mostra quem convidou, sem login.
        mvc.perform(get("/convites/" + convite))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nomeDeQuemConvidou").value("Ana"))
                .andExpect(jsonPath("$.disponivel").value(true));

        // 5) Bruno aceita o convite no perfil dele e leva os próprios dados.
        json(post("/perfil/convite/aceitar"), tokenBruno, "{\"codigo\":\"" + convite.toLowerCase() + "\"}")
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.pessoas.length()").value(2))
                .andExpect(jsonPath("$.convite").doesNotExist());

        // 6) O mês, visto pela Ana: caso do aluguel do documento (R$ 1.000 e R$ 600).
        mvc.perform(autenticado(get("/meses").param("mes", MES), tokenAna))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.pessoas[0].nome").value("Ana"))
                .andExpect(jsonPath("$.pessoas[0].eu").value(true))
                .andExpect(jsonPath("$.pessoas[0].parteContasCasal").value(1000.00))
                .andExpect(jsonPath("$.pessoas[1].parteContasCasal").value(600.00))
                .andExpect(jsonPath("$.pessoas[1].contasIndividuais").value(100.00))
                .andExpect(jsonPath("$.pessoas[1].sobra").value(2300.00))
                .andExpect(jsonPath("$.totalRendas").value(8000.00))
                .andExpect(jsonPath("$.sobraCasal").value(6300.00));

        // 7) Ana vê o gasto que o Bruno trouxe.
        mvc.perform(autenticado(get("/gastos").param("mes", MES), tokenAna))
                .andExpect(jsonPath("$.total").value(1700.00));

        // 8) O código usado deixa de valer: uma terceira pessoa não entra.
        cadastrar("Carla", "carla@teste.com");
        String tokenCarla = JsonPath.read(verificar("carla@teste.com"), "$.accessToken");
        json(post("/perfil/convite/aceitar"), tokenCarla, "{\"codigo\":\"" + convite + "\"}")
                .andExpect(status().isUnprocessableContent())
                .andExpect(jsonPath("$.codigo").value("CONVITE_INVALIDO"));

        // 9) Meta de R$ 1.200 em 6 meses: parcela de R$ 200, dividida 125 / 75 pelas rendas.
        String meta = json(post("/metas"), tokenAna,
                "{\"nome\":\"Viagem\",\"valorAlvo\":1200,\"prazo\":\"" + YearMonth.now().plusMonths(6) + "\"}")
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.parcelaMensal").value(200.00))
                .andExpect(jsonPath("$.partesDaParcela[0].valor").value(125.00))
                .andExpect(jsonPath("$.partesDaParcela[1].valor").value(75.00))
                .andReturn().getResponse().getContentAsString();
        Integer metaId = JsonPath.read(meta, "$.id");
        json(post("/metas/" + metaId + "/depositos"), tokenBruno, "{\"valor\":300}")
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.guardado").value(300.00))
                .andExpect(jsonPath("$.progresso").value(25));
        mvc.perform(autenticado(get("/juntos"), tokenAna))
                .andExpect(jsonPath("$.totalGuardado").value(300.00))
                .andExpect(jsonPath("$.disponivelParaGuardar").value(6000.00))
                .andExpect(jsonPath("$.ideias.length()").isNotEmpty());

        // 10) Histórico do ano inclui o mês atual.
        mvc.perform(autenticado(get("/historico/meses"), tokenAna))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.linhas.length()").value(12))
                .andExpect(jsonPath("$.total.saiu").value(1700.00));
    }

    @Test
    void renovacaoDeSessaoEReusoDeToken() throws Exception {
        cadastrar("Duda", "duda@teste.com");
        String refresh = JsonPath.read(verificar("duda@teste.com"), "$.refreshToken");

        String nova = json(post("/auth/renovar"), null, "{\"refreshToken\":\"" + refresh + "\"}")
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String novoRefresh = JsonPath.read(nova, "$.refreshToken");

        // Reusar o token antigo encerra todas as sessões, inclusive a nova.
        json(post("/auth/renovar"), null, "{\"refreshToken\":\"" + refresh + "\"}").andExpect(status().isUnauthorized());
        json(post("/auth/renovar"), null, "{\"refreshToken\":\"" + novoRefresh + "\"}").andExpect(status().isUnauthorized());
    }

    @Test
    void recuperarSenha() throws Exception {
        cadastrar("Eva", "eva@teste.com");
        verificar("eva@teste.com");
        json(post("/auth/esqueci-senha"), null, "{\"email\":\"eva@teste.com\"}").andExpect(status().isOk());
        String codigo = caixa.ultimoCodigo("eva@teste.com");
        json(post("/auth/redefinir-senha"), null,
                "{\"email\":\"eva@teste.com\",\"codigo\":\"" + codigo + "\",\"novaSenha\":\"outra-senha-2\"}")
                .andExpect(status().isOk());
        json(post("/auth/login"), null, "{\"email\":\"eva@teste.com\",\"senha\":\"outra-senha-2\"}").andExpect(status().isOk());
        json(post("/auth/login"), null, "{\"email\":\"eva@teste.com\",\"senha\":\"senha-forte-1\"}")
                .andExpect(status().isUnauthorized());
    }

    @Test
    void protecoes() throws Exception {
        mvc.perform(get("/meses")).andExpect(status().isUnauthorized()).andExpect(jsonPath("$.codigo").value("NAO_AUTENTICADO"));
        cadastrar("Fábio", "fabio@teste.com");
        cadastrarEsperando("Outro", "FABIO@teste.com", 409);
        json(post("/auth/cadastro"), null, "{\"nome\":\"\",\"email\":\"x\",\"senha\":\"123\"}")
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.campos.length()").value(3));
    }

    // ---------- auxiliares ----------

    private void cadastrar(String nome, String email) throws Exception {
        cadastrarEsperando(nome, email, 201);
    }

    private void cadastrarEsperando(String nome, String email, int status) throws Exception {
        json(post("/auth/cadastro"), null,
                "{\"nome\":\"" + nome + "\",\"email\":\"" + email + "\",\"senha\":\"senha-forte-1\"}")
                .andExpect(status().is(status));
    }

    private String verificar(String email) throws Exception {
        return json(post("/auth/verificar"), null,
                "{\"email\":\"" + email + "\",\"codigo\":\"" + caixa.ultimoCodigo(email) + "\"}")
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
    }

    private static String gasto(String descricao, String valor, String categoria, Integer donoId) {
        return "{\"data\":\"" + YearMonth.now().atDay(1) + "\",\"descricao\":\"" + descricao + "\",\"valor\":" + valor
                + ",\"categoria\":\"" + categoria + "\",\"donoId\":" + donoId + "}";
    }

    private ResultActions json(MockHttpServletRequestBuilder req, String token, String corpo) throws Exception {
        return mvc.perform(autenticado(req, token).contentType(MediaType.APPLICATION_JSON).content(corpo));
    }

    private static MockHttpServletRequestBuilder autenticado(MockHttpServletRequestBuilder req, String token) {
        return token == null ? req : req.header("Authorization", "Bearer " + token);
    }
}
