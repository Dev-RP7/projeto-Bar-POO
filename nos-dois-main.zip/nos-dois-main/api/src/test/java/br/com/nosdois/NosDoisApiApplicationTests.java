package br.com.nosdois;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/** A aplicação sobe e o Flyway aplica as migrações sem erro. */
@SpringBootTest
@ActiveProfiles("test")
class NosDoisApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
