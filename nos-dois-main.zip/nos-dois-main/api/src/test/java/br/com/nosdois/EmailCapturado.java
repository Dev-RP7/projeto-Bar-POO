package br.com.nosdois;

import br.com.nosdois.servico.email.EmailService;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Nos testes, guarda os e-mails "enviados" para ler o código de 6 dígitos. */
@TestConfiguration
public class EmailCapturado {

    public record Email(String para, String assunto, String texto) {
    }

    public static class Caixa implements EmailService {
        private final List<Email> enviados = new ArrayList<>();

        @Override
        public synchronized void enviar(String para, String assunto, String texto) {
            enviados.add(new Email(para, assunto, texto));
        }

        /** Último código enviado para um e-mail. */
        public synchronized String ultimoCodigo(String para) {
            for (int i = enviados.size() - 1; i >= 0; i--) {
                if (enviados.get(i).para().equalsIgnoreCase(para)) {
                    Matcher m = Pattern.compile("\\b(\\d{6})\\b").matcher(enviados.get(i).texto());
                    if (m.find()) {
                        return m.group(1);
                    }
                }
            }
            throw new AssertionError("Nenhum código enviado para " + para);
        }
    }

    @Bean
    @Primary
    public Caixa caixa() {
        return new Caixa();
    }
}
