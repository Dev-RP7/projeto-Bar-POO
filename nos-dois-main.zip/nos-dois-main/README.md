# Nós Dois

App para o casal registrar o que cada um recebe e gasta, ver quanto cada um paga por mês, quanto sobra e o que fazer com a sobra, incluindo metas feitas juntos.

Cada pessoa tem a própria conta e usa o app sozinha desde o primeiro dia. No **Perfil** aparece o convite (código e link) para chamar a outra pessoa; quando ela aceita, os dois passam a ver e registrar tudo junto, cada um no próprio celular.

| Pasta | O que é | Tecnologia |
| --- | --- | --- |
| `api/` | API REST | Java 21, Spring Boot 4.1, Spring Security (JWT), JPA, Flyway, PostgreSQL |
| `app/` | App web instalável (PWA) | Angular 22 (signals, sem zone.js) |

## Telas

- **Mês**: sobra do casal numa barra com a parte de cada um; renda de cada pessoa (cada um edita só a própria); contas do casal e individuais; disponível para guardar; gastos por categoria.
- **Gastos**: lançamento com descrição, valor, data, categoria e dono (nosso, meu ou da outra pessoa); lista agrupada por dia.
- **Histórico**: por dia, por mês (12 meses do ano) e por ano: entrou, saiu, sobrou e guardado.
- **Juntos**: total guardado, metas com barra de progresso, parcela mensal dividida entre os dois, depósitos e ideias para a sobra.
- **Perfil**: convite para o par, aceitar um convite recebido, regra de divisão, trocar senha, backup e sair.

## Regras de cálculo

Todas rodam na API (`api/src/main/java/br/com/nosdois/servico/calculo/Calculadora.java`), com `BigDecimal` e 2 casas.

- **Divisão proporcional**: parte de cada um = contas do casal × renda dele ÷ soma das rendas. **Igual**: metade para cada. Soma das rendas zero: metade para cada. A última parte recebe o resto do arredondamento, então as partes sempre somam o total.
- **Total que cada um paga** = parte das contas do casal + contas só dele. **Sobra** = renda − total que paga.
- **Sobra do casal** = soma das rendas − todos os gastos do mês. **Disponível para guardar** = sobra − depósitos do mês.
- **Renda**: um mês sem registro repete o último mês anterior.
- **Parcela da meta** = (valor − guardado) ÷ meses até o prazo (no mínimo 1). Sem parcela quando não há valor, o prazo passou ou a meta foi alcançada.
- **Reserva de emergência** (referência, não aconselhamento): 3 a 6 vezes a média mensal de gastos dos últimos 6 meses.

Caso de teste do projeto: aluguel de R$ 1.600, rendas de R$ 5.000 e R$ 3.000, divisão proporcional → R$ 1.000 e R$ 600.

## Rodar na sua máquina

Pré-requisitos: Docker Desktop e Node.js 22+.

```bash
# 1. Banco + API (http://localhost:8080, Swagger em /swagger-ui.html)
docker compose up --build

# 2. App (http://localhost:4200), em outro terminal
cd app
npm install
npm start
```

Em desenvolvimento os e-mails não são enviados: o código de 6 dígitos aparece no log da API (`docker compose logs -f api`, procure por `E-MAIL SIMULADO`).

### Testes da API

```bash
cd api
./mvnw test        # Windows: mvnw.cmd test
```

Os testes usam H2 em memória e as mesmas migrações do Flyway. Cobrem as regras de cálculo (incluindo o caso do aluguel) e o fluxo completo: cadastro, verificação de e-mail, convite, divisão do mês, metas, renovação de sessão e recuperação de senha.

## Segurança

- Senhas com BCrypt; códigos de e-mail guardados só como hash, válidos por 15 minutos, com 5 tentativas e limite de 1 envio por minuto e 5 por hora.
- Sessão com token de acesso de 15 minutos e token de renovação de 30 dias, trocado a cada uso. Reusar um token antigo encerra todas as sessões da pessoa.
- Toda requisição confere o usuário e o casal pelo token; cada pessoa só altera a própria renda.

## Publicar

| Parte | Onde | Como |
| --- | --- | --- |
| Banco | [Neon](https://neon.tech) (PostgreSQL) | Crie um projeto e copie a connection string |
| API | [Render](https://render.com) | New → Blueprint → este repositório (usa `render.yaml`); preencha `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`, `APP_URL`, `CORS_ORIGENS` e o SMTP |
| App | [Vercel](https://vercel.com) | Importe o repositório com **Root Directory = `app`** (usa `app/vercel.json`) |
| E-mail | Brevo, Resend ou outro com SMTP | Preencha `SMTP_HOST`, `SMTP_USUARIO`, `SMTP_SENHA` e `EMAIL_REMETENTE` na API |

Antes de publicar o app, coloque a URL da API do Render em `app/src/environments/environment.ts`.

No plano gratuito do Render a API "dorme" depois de 15 minutos sem uso; o primeiro acesso depois disso demora cerca de 1 minuto.

## Variáveis da API

| Variável | Padrão | Para quê |
| --- | --- | --- |
| `DB_URL`, `DB_USERNAME`, `DB_PASSWORD` | PostgreSQL local | Banco |
| `JWT_SECRET` | chave de desenvolvimento | Assinatura dos tokens (≥ 32 caracteres) |
| `APP_URL` | `http://localhost:4200` | Link do convite |
| `CORS_ORIGENS` | `http://localhost:4200` | Sites que podem chamar a API |
| `EMAIL_MODO` | `log` | `log` (desenvolvimento) ou `smtp` |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_USUARIO`, `SMTP_SENHA`, `EMAIL_REMETENTE` | vazio | Envio de e-mail |

## Pontos em aberto

- Gastos fixos que se repetem todo mês (aluguel).
- Percentual de divisão definido pelo casal, além de proporcional e metade.
- Lembretes da parcela mensal das metas.
- Política de privacidade, exclusão da conta e revisão da LGPD.
